# -*- coding: utf-8 -*-
import urllib,re,string,sys,os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import time,threading
from xbmcswift2 import Plugin 
import platform
print platform.system(), platform.release() 
from xml.etree.ElementTree import Element, SubElement, Comment, tostring,ElementTree
canResize = True
try:
   from PIL import Image
   import urllib, cStringIO
   import ntpath
except:
   canResize = False


myPlugin2 = Plugin()
#from resources.lib import anitube,mvonline,mgserieson, myResolver,favorites 
__addon__        = xbmcaddon.Addon()
__cwd__        = __addon__.getAddonInfo('path')
__addonid__      = __addon__.getAddonInfo('id')
__icon__          = __addon__.getAddonInfo("icon")
profile = xbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='plugin.video.inmylibrary')
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )
myImages = xbmc.translatePath( os.path.join( __cwd__, 'images' ) )
background = os.path.join(myImages,"background.png")
editW  = os.path.join(myImages,"editW.png")
editG  = os.path.join(myImages,"editG.png")

if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson


myFolder = xbmc.translatePath(__settings__.getSetting("myFolder"))
print myFolder

if not os.path.exists(myFolder):
   try: 
      os.makedirs(myFolder)
   except:
      print "fail to create the folder from settings"   

if os.path.exists(myFolder):
   mainPath =myFolder
else:
   print "NAO EXISTE ESSE CAMINHO"
   try:
      homeFolder = __cwd__.split("\\")
      mainPath = os.path.join(homeFolder[0],"\InMyLibrary")
   except:
      mainPath =profile 
   try:
      if not os.path.exists(mainPath):
         os.makedirs(mainPath)
   except:
      mainPath =profile 

moviesPath = os.path.join(mainPath, 'Movies')
tvShowPath = os.path.join(mainPath, 'TvShows')
genericPath = os.path.join(mainPath, 'Generic')
tvShowFullPath = os.path.join(mainPath, 'Full')
if not os.path.exists(profile):
        os.makedirs(profile)
if not os.path.exists(moviesPath):
        os.makedirs(moviesPath)
if not os.path.exists(tvShowPath):
        os.makedirs(tvShowPath)
if not os.path.exists(genericPath):
        os.makedirs(genericPath) 
if not os.path.exists(tvShowFullPath):
        os.makedirs(tvShowFullPath)        
        
myTvShows = myPlugin2.get_storage('myTvShows.json', file_format='json') 
myGenerics = myPlugin2.get_storage('myGenerics.json', file_format='json')         

#mySearch = myPlugin2.get_storage('search.json', file_format='json')
#myFavorites = myPlugin2.get_storage('favorites.json', file_format='json')



def MAIN():
    icon = __icon__
    
    xbmcplugin.setContent(addon_handle, 'files')
    li = xbmcgui.ListItem("ADDON SEARCH", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=1")%(myPlugin)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)  

def getPath(type):
   if type=="Movies":
      return moviesPath
   elif type=="TvShows":
      return tvShowPath
   elif type=="TvShowsFull":
      return tvShowFullPath
def showAddMovie(title,path,typeIml,id):
    myAddonsPrefix = myPlugin2.get_storage('myAddonsPrefix.json', file_format='json') 
    prefix = "[INMYLIBRARY]"
    if id in myAddonsPrefix:
       prefix = myAddonsPrefix[id]
    dialog = xbmcgui.Dialog()
    saveTitle = dialog.input('INSIRA O NOME DO FILME',title, type=xbmcgui.INPUT_ALPHANUM)
    saveTitle = cleanTitle(saveTitle, '\/:*?"<>|') 
    saveTitle = saveTitle.decode("UTF-8")
    encPath = urllib.quote(path)
    internalPath = ('plugin://%s?mode=4&path=%s')%(myPlugin,encPath)
    print "path1***********",path
    if typeIml and typeIml == "file":
       internalPath = path
    print "path2***********",internalPath
    if "mode=6" in path and "plugin.video.crackle2fg" in path:
       unPath = urllib.unquote(path)
       print "crackle direct ****************************",unPath
    if saveTitle and path:
       try:
          folder = os.path.join(moviesPath,('%s [%s]')%(saveTitle,prefix))
          file1 = os.path.join(folder,("%s [inmylibrary-%s].strm")%(saveTitle,prefix))
          if not os.path.exists(folder):
             os.makedirs(folder)
          openFile = open(file1,'wt')
          openFile.write(internalPath)
          openFile.close()
          dialog = xbmcgui.Dialog()
          ret = dialog.yesno('FILME SALVO COM SUCESSO', 'Deseja atualizar a coleção?',nolabel="Não",yeslabel="Sim")
          if ret:
             xbmc.executebuiltin('UpdateLibrary(video)')  
          
       
       except:
          dialog = xbmcgui.Dialog()
          dialog.notification('ERRO AO SALVAR O FILME', saveTitle, xbmcgui.NOTIFICATION_ERROR, 3000)  
    else:
       dialog = xbmcgui.Dialog()
       dialog.notification('CANCELANDO', title, xbmcgui.NOTIFICATION_INFO, 3000)   
    #createNfo(saveTitle,folder)



def showAddTvShow(title,path,typeIml,id):
    myAddonsPrefix = myPlugin2.get_storage('myAddonsPrefix.json', file_format='json') 
    prefix = "[INMYLIBRARY]"
    if id in myAddonsPrefix:
       prefix = myAddonsPrefix[id]
    
    print "typeIml",typeIml
    useTitle = title
    useSeason = "01"
    useEpisode = "01"
    chkTitle = xbmc.getCacheThumbName(title)
    
    encPath = urllib.quote(path)
    internalPath = ('plugin://%s?mode=4&path=%s')%(myPlugin,encPath)
    if typeIml and typeIml == "file":
       internalPath = path
    if "last" in myTvShows:
       useTitle = myTvShows["last"]
    else:
       myTvShows["last"] = {}
    
    if "lastSeason" in myTvShows:
       useSeason = myTvShows["lastSeason"]
    else:
       myTvShows["lastSeason"] = {}
    
    if "lastEpisode" in myTvShows:
       useEpisode= myTvShows["lastEpisode"]
       useEpisode = re.sub("[^0-9]", "",useEpisode)
       useEpisode = str(int(useEpisode,10) + 1)
       useEpisode = "00%s"%useEpisode
       useEpisode = useEpisode[-2:]
    else:
       myTvShows["lastEpisode"] = {}
    
    saveTvShow = getFolders(tvShowPath,"SELECIONE UMA PASTA OU CRIE UMA NOVA",useTitle) 
    saveTvShow = cleanTitle(saveTvShow, '\/:*?"<>|') 
    saveTvShow = saveTvShow.decode("UTF-8")
    
    if saveTvShow:
       myTvShows["last"] = saveTvShow
       dialog = xbmcgui.Dialog()
       saveSeason = dialog.input('INSIRA A TEMPORADA',useSeason, type=xbmcgui.INPUT_ALPHANUM)
    
    
    
    if saveTvShow and saveSeason:
       myTvShows["lastSeason"] = saveSeason
       dialog = xbmcgui.Dialog()
       saveEpisode = dialog.input('INSIRA O EPISÓDIO',useEpisode, type=xbmcgui.INPUT_ALPHANUM)
    
    if saveTvShow and saveSeason and saveEpisode:
       myTvShows["lastEpisode"] = saveEpisode
       try:
          folder = os.path.join(tvShowPath,saveTvShow)
          folderSeason = os.path.join(folder,('%s Season %s')%(saveTvShow,saveSeason))
          fileEpisode = os.path.join(folderSeason,'%s s%se%s [inmylibrary-%s].strm'%(saveTvShow,saveSeason,saveEpisode,prefix))
          if not os.path.exists(folder):
             os.makedirs(folder)
          if not os.path.exists(folderSeason):
             os.makedirs(folderSeason)   
    
          if saveSeason =="00":
          #   myImlPath = ('plugin://%s?mode=2&path=%s&id=%s')%(myPlugin,encPath,id)
          #   myImlPath = urllib.quote(myImlPath)
          #   internalPath = ('plugin://%s?mode=4&path=%s')%(myPlugin,myImlPath)
             createNfoTvShow(fileEpisode,saveTvShow,saveSeason,saveEpisode)
          
          openFile = open(fileEpisode,'wt')
          openFile.write(internalPath)
          openFile.close()
          ret = dialog.yesno('FILME SALVO COM SUCESSO', 'Deseja atualizar a coleção?',nolabel="Não",yeslabel="Sim")
          if ret:
             xbmc.executebuiltin('UpdateLibrary(video)')  
       except:
          dialog = xbmcgui.Dialog()
          dialog.notification('ERRO AO SALVAR O EPISÓDIO', title, xbmcgui.NOTIFICATION_ERROR, 3000)   
    else:
       dialog = xbmcgui.Dialog()
       dialog.notification('CANCELANDO', title, xbmcgui.NOTIFICATION_INFO, 3000)
    
    
    myTvShows.sync()

def createNfoTvShow(fileEpisode,saveTvShow,saveSeason,saveEpisode):
   title = "PROCURAR NOVOS EPISÓDIOS"
   title = title.decode("UTF-8","ignore")
   file1  = fileEpisode.replace('.strm','.nfo')
   
   episodedetails = Element('episodedetails')
   title1 = SubElement(episodedetails, 'title')
   title1.text = title
   showtitle = SubElement(episodedetails, 'showtitle')
   showtitle.text = saveTvShow
   season = SubElement(episodedetails, 'season')
   season.text = saveSeason
   episode = SubElement(episodedetails, 'episode')
   episode.text = saveEpisode
      
   ElementTree(episodedetails).write(file1)  

def showAddFiles():
   import urllib, cStringIO
   myAddonsPrefix = myPlugin2.get_storage('myAddonsPrefix.json', file_format='json') 
   myLastSequence = myPlugin2.get_storage('myLastSequence.json', file_format='json')
   
   if "last" in myGenerics:
      last = myGenerics["last"]
   else:
      myGenerics["last"] = {}
      last = ""
   
   saveFolder = getFolders(genericPath,"SELECIONE UMA PASTA OU CRIE UMA NOVA",last) 
   saveFolder = cleanTitle(saveFolder, ':*?"<>|') 
   saveFolder = saveFolder.decode("UTF-8")   
   length  = len(myLastSequence.keys())
   
   
     
   if saveFolder:
       myGenerics["last"] = saveFolder
       myGenerics.sync()
       dialog = xbmcgui.Dialog()
       saveThumbs = dialog.yesno('THUMBNAIL','DESEJA SALVAR O THUMBNAIL DO VÍDEO ?',nolabel="Não",yeslabel="Sim")
       folder = os.path.join(genericPath,saveFolder)
       if not os.path.exists(folder):
          os.makedirs(folder)
       
       imgDialog = xbmcgui.DialogProgress()
       imgDialog.create('Coletando informações sobre os vídeos', 'Aguarde...')
       count = 1
       for i,files in enumerate(myLastSequence):
         try: 
            label = myLastSequence[files]["label"]
            label = label
            label = cleanTitle(label, '\/:*?"<>|') 
            path = myLastSequence[files]["path"]
            filetype = myLastSequence[files]["filetype"]
            id = myLastSequence[files]["id"]
            thumbnail = myLastSequence[files]["thumbnail"]
            
            percent = int((count*100)/length)
            imgDialog.update(percent,"Salvando arquivo ",label)
            count = count+1
      
            encPath = path
            internalPath = ('plugin://%s?mode=4&path=%s')%(myPlugin,encPath)
            if filetype == "file":
               internalPath = urllib.unquote(path)
      
            
            
            prefix = "[INMYLIBRARY]"
            if id in myAddonsPrefix:
               prefix = myAddonsPrefix[id]
        
            saveFile  = os.path.join(folder,("%s [inmylibrary-%s].strm")%(label,prefix))  
            openFile = open(saveFile,'wt')
            openFile.write(internalPath)
            openFile.close()
  
            if saveThumbs:
               saveImg  = os.path.join(folder,("%s [inmylibrary-%s].tbn")%(label,prefix))
               thumbnail = urllib.unquote(thumbnail)
               thumbnail = thumbnail.replace("image://","")
               if (thumbnail[len(thumbnail)-1]=='/'):
                 thumbnail=thumbnail[0:len(thumbnail)-1]
               urllib.urlretrieve(thumbnail, saveImg)
         except:
            pass
       imgDialog.close()     
            
def showAddFilesUnit(label,path,filetype,id,thumbnail):
   import urllib, cStringIO
   myAddonsPrefix = myPlugin2.get_storage('myAddonsPrefix.json', file_format='json') 
   myLastSequence = myPlugin2.get_storage('myLastSequence.json', file_format='json')
   
   if "last" in myGenerics:
      last = myGenerics["last"]
   else:
      myGenerics["last"] = {}
      last = ""
   
   saveFolder = getFolders(genericPath,"SELECIONE UMA PASTA OU CRIE UMA NOVA",last) 
   print "save folder is +++++++++++++++",saveFolder
   saveFolder = cleanTitle(saveFolder, ':*?"<>|') 
   saveFolder = saveFolder.decode("UTF-8")
   hasIml = re.search("\[iml\]",saveFolder,re.IGNORECASE)
   saveFolder = re.sub('\[iml\]',"",saveFolder,flags=re.IGNORECASE)
   saveFolder = saveFolder.rstrip(" ")  
   length  = len(myLastSequence.keys())
   
   
   
   if saveFolder:
       myGenerics["last"] = saveFolder
       myGenerics.sync()
       folder = os.path.join(genericPath,saveFolder)
       dialog = xbmcgui.Dialog()
       saveThumbs = dialog.yesno('THUMBNAIL','DESEJA SALVAR O THUMBNAIL DO VÍDEO ?',nolabel="Não",yeslabel="Sim")
       
       if not os.path.exists(folder):
          os.makedirs(folder)
       
       imgDialog = xbmcgui.DialogProgress()
       imgDialog.create('Coletando informações sobre os vídeos', 'Aguarde...')
       count = 1
       try: 
            label = cleanTitle(label, '\/:*?"<>|')
            label = unicode(label, 'UTF-8') 
            percent = 100
            imgDialog.update(percent,"Salvando arquivo ",label)
            count = count+1
      
            encPath = urllib.quote(path)
            internalPath = ('plugin://%s?mode=4&path=%s')%(myPlugin,encPath)
            if filetype == "file":
               internalPath = path
      
            if hasIml:
               
               label = "[IML] %s"%label
               myImlPath = ('plugin://%s?mode=2&path=%s&id=%s')%(myPlugin,encPath,id)
               myImlPath = urllib.quote(myImlPath)
               internalPath = ('plugin://%s?mode=4&path=%s')%(myPlugin,myImlPath)
      
            prefix = "[INMYLIBRARY]"
            if id in myAddonsPrefix:
               prefix = myAddonsPrefix[id]
        
            saveFile  = os.path.join(folder,("%s [inmylibrary-%s].strm")%(label,prefix))  
            openFile = open(saveFile,'wt')
            openFile.write(internalPath)
            openFile.close()
  
            if saveThumbs:
               saveImg  = os.path.join(folder,("%s [inmylibrary-%s].tbn")%(label,prefix))
               thumbnail = urllib.unquote(thumbnail)
               thumbnail = thumbnail.replace("image://","")
               if (thumbnail[len(thumbnail)-1]=='/'):
                 thumbnail=thumbnail[0:len(thumbnail)-1]
               urllib.urlretrieve(thumbnail, saveImg)
       except:
            pass
       imgDialog.close()                            

def getFolders(dir,message="",last=""):
   #index = xbmcgui.Dialog().select('Selecione um dos hosts suportados :', hosts)
   myFolders  = get_immediate_subdirectories(dir)
   list = []
   if last:
      list.append(last)
   list.append("NOVA PASTA")   
   list = list + myFolders
   index = xbmcgui.Dialog().select(message, list)
   if index!=-1:
      folderName =  list[index]
      if folderName == "NOVA PASTA":
         dialog = xbmcgui.Dialog()
         folderName = dialog.input('INSIRA O NOME DA PASTA',"", type=xbmcgui.INPUT_ALPHANUM) 
      return folderName     
   else:
      return ""



def get_immediate_subdirectories(dir):
    return [name for name in os.listdir(dir)
            if os.path.isdir(os.path.join(dir, name))]



def showAddMovie2(title,path):
    print "call to add movie 2",title,path
    inputMovie = InputDialog(actualTitle=title,type="Movie")
    inputMovie.showInputDialogMovie()
    print "Logged_in value: "+str(inputMovie.title_txt),path
    saveTitle = str(inputMovie.title_txt)
    saveTitle = cleanTitle(saveTitle, '\/:*?"<>|') 
    encPath = urllib.quote(path)
    internalPath = ('plugin://%s?mode=4&path=%s')%(myPlugin,encPath)
    
    if saveTitle and path:
       folder = os.path.join(moviesPath,saveTitle)
       file1 = os.path.join(folder,("%s.strm")%saveTitle)
       if not os.path.exists(folder):
          os.makedirs(folder)
       openFile = open(file1,'wt')
       openFile.write(internalPath)
       openFile.close()
    del inputMovie
    dialog = xbmcgui.Dialog()
    d = dialog.input('Enter secret code',title, type=xbmcgui.INPUT_ALPHANUM)
    print "my title", d
def cleanTitle(value, deletechars):
    for c in deletechars:
        value = value.replace(c,'')
    return value;

 

class InputDialog(xbmcgui.WindowDialog):
    def __init__(self,*args, **kwargs ):
        self.type  = kwargs[ "type" ]
        self.actualTitle = kwargs[ "actualTitle" ]
        if self.type == "Movie":
           self.openMovie()
        
    def openMovie(self):    
        self.addControl(xbmcgui.ControlImage(280,190,500,300, "ContentPanel.png"))
        self.title = xbmcgui.ControlEdit(300, 200, 400, 60, 'Title', 'font12')
        self.addControl(self.title)
        self.addMovie = xbmcgui.ControlButton(300, 400, 130, 50, 'ADD TO LIBRARY', font='font16_title',focusedColor='0xDD171717')
        self.addControl(self.addMovie)
        
        self.setFocus(self.title)
        self.title_txt = ""
    
    def openTvShow(self):    
        self.addControl(xbmcgui.ControlImage(280,190,500,300, "ContentPanel.png"))
        self.title = xbmcgui.ControlEdit(300, 200, 400, 60, 'Title', 'font12')
        self.addControl(self.title)
        self.addMovie = xbmcgui.ControlButton(300, 400, 130, 50, 'ADD TO LIBRARY', font='font16_title',focusedColor='0xDD171717')
        self.addControl(self.addMovie)
        
        self.setFocus(self.title)
        self.title_txt = ""    
    
    def onControl(self, control):
        if control == self.addMovie:
            self.close()
            self.title_txt = self.title.getText()
    def showInputDialogMovie(self):
        self.title.setPosition(300, 200)
        self.title.setWidth(400)
        self.title.setHeight(60)
        self.title.setText(self.actualTitle)
        self.title.controlDown(self.addMovie)
        
        self.addMovie.controlUp(self.title)
        self.addMovie.setWidth(300)
        self.doModal() 
        
        
myPlugin = sys.argv[0]
if myPlugin=="default.py":
   myPlugin = "plugin.video.inmylibrary"                           