import sys, itertools, re, os, random, inspect
import string
if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
from xbmcswift2 import Plugin
from resources.lib import prefixControl

plugin = Plugin()


class Main():
   def __init__( self ):
     xbmcgui.Window( 10000 ).clearProperty('INMYLIBRARY_SERVICE_RUN')
     self.Monitor = MonitorIml(update_listitems = self._updateLibrary)
     self.CtrPlayer = MyPlayerIml(playerStart = self._playerStart)
     xbmcgui.Window( 10000 ).clearProperty('INMYLIBRARY_SERVICE')
     xbmc.sleep(2000)
     xbmcgui.Window( 10000 ).setProperty('INMYLIBRARY_SERVICE', 'true')
     xbmc.sleep(500)
     self._daemon()
   def _updateLibrary(self,database):
      if(database == "video"):
         print "video update on InMyLibrary"
         prefixControl.libUpdate()
      elif (database == "music"):
         print "audio update"
   def _daemon( self ):
        # keep running until xbmc exits or another instance is started
        while (not xbmc.abortRequested) and xbmcgui.Window( 10000 ).getProperty('INMYLIBRARY_SERVICE') == 'true':                  
            xbmc.sleep(1000)
        if xbmc.abortRequested:
            log('script stopped: xbmc quit')
        else:
            log('script stopped: new script instance started')           
   
   def _playerStart():
      print "called function to player started"  



class MonitorIml(xbmc.Monitor):
    def __init__(self,*args, **kwargs):
        xbmc.Monitor.__init__(self)
        self.update_listitems = kwargs['update_listitems']

    def onDatabaseUpdated(self, database):
        self.update_listitems(database)



def log(message):
    xbmc.log(msg=message)



class MyPlayerIml(xbmc.Player):
  def __init__(self,*args, **kwargs):
    xbmc.Player.__init__(self)
    self.playerStart = kwargs['playerStart']

  def playing_status(self):
    if self.isPlaying():
      return 'status=playing' + ';' + self.playing_type()
    else:
      return 'status=stopped'

  def playing_type(self):
    type = 'unkown'
    if (self.isPlayingAudio()):
      type = "music"  
    else:
      if xbmc.getCondVisibility('VideoPlayer.Content(movies)'):
        filename = ''
        isMovie = True
        try:
          filename = self.getPlayingFile()
          print "this file is playing",filename
        except:
          pass
        if isMovie:
          type = "movie"
      elif xbmc.getCondVisibility('VideoPlayer.Content(episodes)'):
        # Check for tv show title and season to make sure it's really an episode
        if xbmc.getInfoLabel('VideoPlayer.Season') != "" and xbmc.getInfoLabel('VideoPlayer.TVShowTitle') != "":
           type = "episode"
    return 'type=' + type

  def onPlayBackStarted(self):
    log('player starts')
    isPlaying= self.playing_type()
    print isPlaying
  def onPlayBackEnded(self):
    print "playback end"

  def onPlayBackStopped(self):
    print "playback stop"

  def onPlayBackPaused(self):
    print "playback pause" 

  def onPlayBackResumed(self):
    print "playback resume"
  def onQueueNextItem(self):
     print "called another item"

addon_handle = 5 
def get_params():
    print "services called"
        
if (__name__ == "__main__"):
   Main()
   del MonitorIml
   del MyPlayerIml
   del Main

