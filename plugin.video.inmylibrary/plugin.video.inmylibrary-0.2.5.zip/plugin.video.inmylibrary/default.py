# -*- coding: utf-8 -*-
import urllib,re,string,sys,os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import time,threading
from xbmcswift2 import Plugin 
from metahandler import metahandlers

myPlugin2 = Plugin()
myMeta = metahandlers.MetaData(preparezip=True)
from resources.lib import dialogAdd,prefixControl
__addon__        = xbmcaddon.Addon()
__cwd__        = __addon__.getAddonInfo('path')
__addonid__      = __addon__.getAddonInfo('id')
__icon__          = __addon__.getAddonInfo("icon")
profile = xbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
cache = xbmc.translatePath(os.path.join(profile,"cache"))
__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='plugin.video.inmylibrary')
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )

if not os.path.exists(cache):
   os.makedirs(cache)

if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson

isGotham = True
xbmcVersion = xbmc.getInfoLabel( "System.BuildVersion" )
print xbmcVersion
xbmcVersion = xbmcVersion[:2]
print xbmcVersion
findGotham = re.search("GOTHAM",xbmcVersion,re.IGNORECASE)
if xbmcVersion =="13" or findGotham:
   print "IS GOTHAM"
   isGotham = True

#mySearch = myPlugin2.get_storage('search.json', file_format='json')
#myFavorites = myPlugin2.get_storage('favorites.json', file_format='json')

isBusy  = False
isCanceled = False

myLastIml = myPlugin2.get_storage('myLastIml.json', file_format='json')  

def MAIN():
    myMovieTest = myMeta.search_movies("Robocop")
    print repr(myMovieTest) 
    icon = __icon__
    xbmcplugin.setContent(addon_handle, 'files')
    li = xbmcgui.ListItem("PROCURAR ADDONS", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=1")%(myPlugin)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
     
    li = xbmcgui.ListItem("FILMES - INSERIR PREFIXO [IML]", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=6")%(myPlugin)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=False)
     
    li = xbmcgui.ListItem("EPISÓDIOS - INSERIR PREFIXO [IML]", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=7")%(myPlugin)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=False)  
    xbmcplugin.endOfDirectory(addon_handle)  
def getAddonsVideo():
    if isGotham:
       getAddonsVideo2()
    else:
       li = xbmcgui.ListItem("SOMENTE PARA XBMC GOTHAM")
       url = ""
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=False)
       xbmcplugin.endOfDirectory(addon_handle)  

def getAddonsVideo2():   
   
   print "get addons video"
   json_params  =  '"params": {"type" : "xbmc.addon.video","properties": ["name","description","path","thumbnail","broken","enabled"]}'
   json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.GetAddons",%s , "id": 1}'% json_params)   
   json_request = unicode(json_request, 'utf-8', errors='ignore')
   json_response = simplejson.loads(json_request)
   if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('addons'):
      print "json called"
      xbmcplugin.setContent(addon_handle, 'files')
      myAddonsPrefix = myPlugin2.get_storage('myAddonsPrefix.json', file_format='json')
      for addons in json_response['result']['addons']:
         id = addons["addonid"]
         prefix = ""
         if id in myAddonsPrefix:
            prefix = myAddonsPrefix[id]
         name = "SEARCH ADDON - %s"%addons["name"]
         description = addons["description"]
         path = "useid"
         thumbnail = addons["thumbnail"]
         broken = addons["broken"]
         enabled = addons["enabled"]
         if enabled == True and broken == False and id !="plugin.video.inmylibrary":
            li = xbmcgui.ListItem(name,thumbnailImage=thumbnail)
            url  = ('%s?mode=2&path=%s&id=%s')%(myPlugin,path,id)
            contextMenuItems = []
            contextMenuItems.append(("MUDAR PREFIXO %s"%prefix,'XBMC.RunScript(%s,%s,?mode=%s&id=%s&prefix=%s)'% ("plugin.video.inmylibrary",1,"8",id,prefix)))
            li.addContextMenuItems(contextMenuItems, replaceItems=True)
            
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
      xbmcplugin.endOfDirectory(addon_handle) 

def changePrefix(id,prefix):
   myAddonsPrefix = myPlugin2.get_storage('myAddonsPrefix.json', file_format='json')
   dialog = xbmcgui.Dialog()
   prefix2 = dialog.input('INSIRA UM PREFIXO PARA %s. Ex. NTF'%id,prefix, type=xbmcgui.INPUT_ALPHANUM)      
   if prefix:
         myAddonsPrefix[id]=prefix2
         myAddonsPrefix.sync()
         changePrefixMovies(prefix,prefix2)
         changePrefixEpisodes(prefix,prefix2)
         dialog = xbmcgui.Dialog()
         ok = dialog.ok('PREFIXO ALTERADO', 'VOCÊ PRECISA DELETAR OS ARQUIVOS DA BIBLIOTECA,',"IMPORTAR E GERAR O PREFIXO NOVAMENTE")
         xbmc.executebuiltin("XBMC.Container.Refresh")

def changePrefixMovies(prefix,prefix2):
   moviesFolder = dialogAdd.getPath("Movies")
   for folders in os.listdir(moviesFolder):
      print folders
      folderPath = os.path.join(moviesFolder,folders)
      folderChange = folders.replace("[%s]"%prefix,"[%s]"%prefix2)
      os.rename(os.path.join(moviesFolder, folders), os.path.join(moviesFolder, folderChange))
   for folders in os.listdir(moviesFolder):
      folderPath = os.path.join(moviesFolder,folders)
      for files in os.listdir(folderPath):
         fileChange = files.replace("[inmylibrary-%s]"%prefix,"[inmylibrary-%s]"%prefix2)
         os.rename(os.path.join(moviesFolder, folders,files), os.path.join(moviesFolder, folders,fileChange))
         print fileChange

def changePrefixEpisodes(prefix,prefix2):
   moviesFolder = dialogAdd.getPath("TvShows")
   for folders in os.listdir(moviesFolder):
      folderPath = os.path.join(moviesFolder,folders)
      for folders2 in os.listdir(folderPath):
         folderPath2 = os.path.join(folderPath,folders2)
         for files in os.listdir(folderPath2):
            fileChange = files.replace("[inmylibrary-%s]"%prefix,"[inmylibrary-%s]"%prefix2)
            os.rename(os.path.join(moviesFolder, folders,folders2,files), os.path.join(moviesFolder, folders,folders2,fileChange))
            print fileChange


def changePrefixTvShows(prefix,prefix2):
   moviesFolder = dialogAdd.getPath("Movies")
   for folders in os.listdir(moviesFolder):
      print folders
      folderPath = os.path.join(moviesFolder,folders)
      folderChange = folders.replace(prefix,prefix2)
      os.rename(os.path.join(moviesFolder, folders), os.path.join(moviesFolder, folderChange))
   for folders in os.listdir(moviesFolder):
      folderPath = os.path.join(moviesFolder,folders)
      for files in os.listdir(folderPath):
         fileChange = files.replace(prefix,prefix2)
         os.rename(os.path.join(moviesFolder, folders,files), os.path.join(moviesFolder, folders,fileChange))
         print fileChange

def getAddonsPath(path,id):
   myAddonsPrefix = myPlugin2.get_storage('myAddonsPrefix.json', file_format='json')
   if id in myAddonsPrefix:
      getAddonsPath2(path,id)
   else:
      dialog = xbmcgui.Dialog()
      prefix = dialog.input('INSIRA UM PREFIXO PARA %s. Ex. NTF'%id,"", type=xbmcgui.INPUT_ALPHANUM)      
      if prefix:
         myAddonsPrefix[id]=prefix
         myAddonsPrefix.sync()
         getAddonsPath2(path,id)
      
def getAddonsPath2(path,id):
   print "my paths",path,id
   deleteFile  = os.path.join(myPlugin2.storage_path,'myLastSequence.json')
   if os.path.exists(deleteFile):
        os.remove(deleteFile)
   
   repInterr = urllib.quote("?")
   checkPath = path.split("?")
   if len(checkPath)>2:
      k = path.find("?")
      path = path[:k] + "?" + path[k+1:].replace("?",repInterr)
      print "new path&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&", path,len(checkPath)
   if path != "useid":
      directory = path      
   else:
      directory = "plugin://%s"%id
   print "get addons video",path,id
   json_params  =  '"params": {"properties": ["thumbnail","genre","plot","file"],"directory" : "%s","media" : "files"}'%directory
   print json_params
   json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory",%s , "id": 1}'% json_params)   
   print "json request", json_request
   json_request = unicode(json_request, 'utf-8', errors='ignore')
   json_response = simplejson.loads(json_request)
   if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('files'):
      print "json called directory"
      myLastSequence = myPlugin2.get_storage('myLastSequence.json', file_format='json')
      for myFiles in json_response['result']['files']:

         name = "IML - %s"%myFiles["label"]
         label = myFiles["label"]
         filetype = myFiles["filetype"]
         filetypeUpper = filetype.upper()
         path = myFiles["file"]
         print repr(path)
         path= urllib.quote_plus(path.encode("utf-8"))
         thumbnail = myFiles["thumbnail"]
         
         internalId = xbmc.getCacheThumbName("%s%s"%(label,path)).replace(".tbn","")
         myLastSequence[internalId]={}
         myLastSequence[internalId]["label"]= label
         myLastSequence[internalId]["path"]= path
         myLastSequence[internalId]["filetype"]= filetype
         myLastSequence[internalId]["id"]= id
         myLastSequence[internalId]["thumbnail"]= thumbnail
         
         li = xbmcgui.ListItem(name,thumbnailImage=thumbnail)
         url  = ('%s?mode=2&path=%s&id=%s')%(myPlugin,path,id)
         
         contextMenuItems = []
         contextMenuItems.append(("INSERIR FILME - %s"%filetypeUpper,'XBMC.RunScript(%s,%s,?mode=%s&label=%s&path=%s&typeIml=%s&id=%s)'% ("plugin.video.inmylibrary",1,"3",label,path,filetype,id)))
         contextMenuItems.append(("INSERIR EPISODIO - %s"%filetypeUpper,'XBMC.RunScript(%s,%s,?mode=%s&label=%s&path=%s&typeIml=%s&id=%s)'% ("plugin.video.inmylibrary",1,"5",label,path,filetype,id)))
         contextMenuItems.append(("CAPUTURAR JANELA ATUAL - GENERIC",'XBMC.RunScript(%s,%s,?mode=%s&label=%s&path=%s&typeIml=%s&id=%s)'% ("plugin.video.inmylibrary",1,"9",label,path,filetype,id)))
         contextMenuItems.append(("CAPUTURAR LINK - GENERIC",'XBMC.RunScript(%s,%s,?mode=%s&label=%s&path=%s&typeIml=%s&id=%s&thumbnail=%s)'% ("plugin.video.inmylibrary",1,"11",label,path,filetype,id,thumbnail)))
         contextMenuItems.append(("CAPTURAR PRÓXIMOS - FULL",'XBMC.RunScript(%s,%s,?mode=%s&label=%s&path=%s&typeIml=%s&id=%s)'% ("plugin.video.inmylibrary",1,"10",label,path,filetype,id)))
         contextMenuItems.append(("CHECAR LEGENDA-FILME",'XBMC.RunScript(%s,%s,?mode=%s&label=%s)'% ("plugin.video.inmylibrary",1,"100",label)))
         #contextMenuItems.append(("INSERIR EPISÓDIO - ARQUIVO",'XBMC.RunScript(%s,%s,?mode=%s&label=%s&path=%s&typeIml=file)'% ("plugin.video.inmylibrary",1,"5",label,path)))
         li.addContextMenuItems(contextMenuItems, replaceItems=True)
         
         xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)

      myLastSequence.sync()
      xbmcplugin.endOfDirectory(addon_handle) 



  

def getTvShow(path,id,myFolder="",label=""):
   #filename = (''.join(c for c in unicode(filename, 'utf-8') if c not in '/\\:?"*|<>')).strip(' .')
   print "my path is ",path
   if label:
      label  = label.decode("UTF-8","ignore")
      label = dialogAdd.cleanTitle(label, '\/:*?"<>|') 
   tvCache = xbmc.getCacheThumbName(path).replace(".tbn","") 
   myTvShow = myPlugin2.get_storage('%s.json'%tvCache, file_format='json')
   folder = dialogAdd.getPath("TvShowsFull")
   if myFolder:
      folder = myFolder
   else:
      folder = os.path.join(folder,label)
      if not os.path.exists(folder):
         os.makedirs(folder)
   json_params  =  '"params": {"properties": ["thumbnail","genre","plot","file"],"directory" : "%s","media" : "files"}'%path
   json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory",%s , "id": 1}'% json_params)   
   json_request = unicode(json_request, 'utf-8', errors='ignore')
   json_response = simplejson.loads(json_request)
   if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('files'):
      print "json called directory"
      myAddonsPrefix = myPlugin2.get_storage('myAddonsPrefix.json', file_format='json') 
      prefix = "[INMYLIBRARY]"
      if id in myAddonsPrefix:
         prefix = myAddonsPrefix[id]
      
      myLastSequence = myPlugin2.get_storage('myLastSequence.json', file_format='json')
      for myFiles in json_response['result']['files']:
         name = "IML - %s"%myFiles["label"]
         label = myFiles["label"]
         label = dialogAdd.cleanTitle(label, '\/:*?"<>|').rstrip(" ")
         filetype = myFiles["filetype"]
         filetypeUpper = filetype.upper()
         path = myFiles["file"]
         path= urllib.quote_plus(path)
         thumbnail = myFiles["thumbnail"]
         
         limitLabel = label[:80]
         internalFolder  = os.path.join(folder,limitLabel)
         if filetype == 'file':
            internalFolder = '%s [inmylibrary-%s].strm'%(internalFolder,prefix)
         print repr(internalFolder)
         if isinstance(internalFolder, str):
            print "ordinary string"
         elif isinstance(internalFolder, unicode):
            print "unicode string"
         else:
            print "not a string"
         internalId = xbmc.getCacheThumbName("%s"%(path)).replace(".tbn","")
         myTvShow[internalId]={}
         myTvShow[internalId]["internalFolder"]= internalFolder
         myTvShow[internalId]["label"]= label
         myTvShow[internalId]["path"]= path
         myTvShow[internalId]["filetype"]= filetype
         myTvShow[internalId]["id"]= id
         myTvShow[internalId]["thumbnail"]= thumbnail
         myTvShow[internalId]["upId"]= tvCache

      myTvShow.sync()
      return myTvShow
   else:
      return ""

def getTvShowContent(path,id,myFolder="",label=""):
   myAddonsPrefix = myPlugin2.get_storage('myAddonsPrefix.json', file_format='json') 
   imgDialog = xbmcgui.DialogProgress()
   imgDialog.create('Criando Pastas', 'Aguarde...')
   prefix = "[INMYLIBRARY]"
   if id in myAddonsPrefix:
      prefix = myAddonsPrefix[id]
   
   content = getTvShow(path,id,myFolder,label)
   for i,items in enumerate(content):
      print "has content"
      label = content[items]["label"]
      imgDialog.update(50,"Cridando Pastas",label)
      id = content[items]["id"]
      upId = content[items]["upId"]
      path1 = content[items]["path"]
      id = content[items]["id"]
      internalFolder = content[items]["internalFolder"]
      filetype = content[items]["filetype"]
      if filetype == "directory":
         print "is FOlder",repr(internalFolder)  
         if not os.path.exists(internalFolder):
            os.makedirs(internalFolder)
         fileToSave = '%s [inmylibrary-%s].strm'%(internalFolder,prefix)
         openFile = open(fileToSave,'wt')
         openFile.write(path1)
         openFile.close()
      if filetype == "file":
         print "is file",repr(label),repr(internalFolder)     
         openFile = open(internalFolder,'wt')
         openFile.write(path1)
         openFile.close()
   if (imgDialog.iscanceled()): 
      global isCanceled
      isCanceled = True
      print "Canceled ************************************************************************************************"
      return
   imgDialog.close()
   reuseContent(content)     

def reuseContent(content):
   print "calling again *****************************************"
   for i,items in enumerate(content):
      print isCanceled
      if isCanceled:
         print "Canceled ************************************************************************************************"
         return;
      filetype = content[items]["filetype"]
      id = content[items]["id"]
      upId = content[items]["upId"]
      path1 = content[items]["path"]
      path1= urllib.unquote_plus(path1)
      id = content[items]["id"]
      internalFolder = content[items]["internalFolder"]   
      if filetype  =="directory":
         getTvShowContent(path1,id,internalFolder,"")


def checkSubtitle(title):
   #{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory" : "plugin://service.subtitles.legendastv?action=search&languages=English%2cPortuguese%20(Brazil)","media" : "files"}, "id": 1}
   #{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory" : "plugin://service.subtitles.legendastv?action=outSearch&title=Thor&year=2014","media" : "files"}, "id": 1}
   dialog = xbmcgui.Dialog()
   year = ""
   title = dialog.input('INSIRA O NOME DO FILME',title, type=xbmcgui.INPUT_ALPHANUM) 
   if title:
      findYear = re.findall("(.+?) \((\d*)\)",title)
      if findYear:
         title =  findYear[0][0]
         year = findYear[0][1]
      print "checando título ++++++++", title,repr(findYear)
      imgDialog = xbmcgui.DialogProgress()
      imgDialog.create('LEGENDAS.TV', 'Aguarde...')
      imgDialog.update(50,"Listando legendas","Aguardando o addon Lengendas.tv")
      directory = "plugin://service.subtitles.legendastv?action=outSearch&title=%s&year=%s"%(title,year)
      json_params  =  '"params": {"directory" : "%s","media" : "files"}'%directory
      json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory",%s , "id": 1}'% json_params)   
      print "json request", json_request
      json_request = unicode(json_request, 'utf-8', errors='ignore')
      json_response = simplejson.loads(json_request)
      if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('files'):
         imgDialog.update(100,"Listando legendas","Aguardando o addon Lengendas.tv")
         print "json called directory"
         myLastSequence = myPlugin2.get_storage('myLastSequence.json', file_format='json')
         list = []
         for myFiles in json_response['result']['files']: 
            label = myFiles["label"]
            if label == "Portuguese (Brazil)":
               fullFile  = myFiles["file"]
               match = re.findall("download_url=(.+?)&filename",fullFile)
               if match:
                  title = match[0].split("/")
                  if len(title)>0:
                     print "title1", title
                     title = title[len(title)-1]
                     print "title2",title
                     list.append(title)
         imgDialog.close()
         if len(list)>0:
            index = xbmcgui.Dialog().select("LISTA DE LEGENDAS EM PT-BR", list)             


def crackle(path):
   li = xbmcgui.ListItem("Crackle")
   #url  = ('%s?mode=2&path=%s&id=%s')%("plugin.video.crackle2fg",path,id)
   url = path.replace("plugin://","")
   xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li)
   xbmcplugin.endOfDirectory(addon_handle) 


def get_params():
    print "***************************************************************************************************************************"
    print sys.argv
    param=[]
    paramstring=sys.argv[2]
    
    if len(paramstring)>=2:
        params=sys.argv[2]
        #print "params", params
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
            elif (len(splitparams))==3:
                param[splitparams[0]]=splitparams[1]+splitparams[2]    
    return param

        
params=get_params()
myPlugin = sys.argv[0]
addon_handle = int(sys.argv[1])
mode= None
url =None
path= None
label = None
id = None
typeIml = None
prefix = ""
thumbnail = None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: mode=int(params["mode"])
except: pass
try: path= urllib.unquote_plus(params["path"])
except: pass
try: id= params["id"]
except: pass
try: label=params["label"]
except: pass
try: typeIml=params["typeIml"]
except: pass
try: prefix=params["prefix"]
except: pass
try: thumbnail=params["thumbnail"]
except: pass


if mode == None and url==None:
   print "MAIN WINDOW"
   MAIN()
elif mode == 1:
   getAddonsVideo()
   
elif mode == 2:
   
   if path:
      getAddonsPath(path,id)
      lastIml  = "%sxxx%s"%(path,id)
      myLastIml["last"] = urllib.quote_plus(lastIml.encode("utf-8"))
      myLastIml.sync()
elif mode == 3:
   print "call to add movie",path,label
   print repr(params)
   if path and label:
      dialogAdd.showAddMovie(label,path,typeIml,id)
       
elif mode==4:
   xbmc.executebuiltin('PlayerControl(Stop)')
   
   print "player path called", path
   #xbmcgui.Window( 10000 ).setProperty('INMYLIBRARY_SERVICE_PATH', path)
   #xbmcgui.Window( 10000 ).setProperty('INMYLIBRARY_SERVICE_RUN', 'true')
   if("xxx" in path):
      print "in my library call ************************", path
      path = urllib.quote_plus(path.encode("utf-8"))
      split = path.split("xxx")
      path = "plugin://plugin.video.inmylibrary?mode=2&path=%s&id=%s"%(split[0],split[1]) 
   xbmc.executebuiltin('Container.Update(%s)'%path)
   if "mode=6" in path and "plugin.video.crackle2fg" in path:
       print "crackle mode 6"
       crackle(path)
   
   
   
elif mode == 5:
   print "call to add episode",path,label
   print repr(params)
   print "typeIml",typeIml
   if path and label:
      dialogAdd.showAddTvShow(label,path,typeIml,id) 
elif mode == 6:
   prefixControl.updateMovies()  
elif mode == 7:
   prefixControl.updateEpisodes()
elif mode == 8:
   changePrefix(id,prefix) 
elif mode == 9:
   dialogAdd.showAddFiles()
elif mode == 10:
   if path:
      getTvShowContent(path,id,"",label)
elif mode == 11:
      dialogAdd.showAddFilesUnit(label,path,typeIml,id,thumbnail) 
elif mode == 12:
   print url
      
elif mode == 100:
      checkSubtitle(label)                                              