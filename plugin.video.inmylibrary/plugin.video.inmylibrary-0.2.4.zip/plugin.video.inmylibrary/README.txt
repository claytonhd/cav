THIS IS FOR ANOTHER ADDON THAT I MADE A LONG TIME AGO, DON�T READ
INFORMATION FOR SKINNERS
------------------------


CONTENTS:
1. Introduction
2. Running the addon
3. Infolabels lista �nica
4. Infolables v�rias listas.


1. Introdu��o:
----------------
Este script ir� retornar :
- Uma lista de filmes aleat�ria.
- Uma lista de filmes recentes.
- Uma lista com os filmes em progresso.
 
2. Rodando o addon:
---------------------
- Fa�a o addon rodar ao iniciar a skin e ao retornar � home com o comando:  
  RunScript(script.allinone,movies=true&amp;limit=10) .
  Este comando preeche todas as listas e o uso ao iniciar a skin n�o � optativa.
  A primeira lista ficar dispon�vel para o uso � a Progress. 
  Este comando tamb�m pode ser usado por quem quer ter v�rias listas, uma para cada tipo (random, progress e recents), pois preenche as infolabels
  descristas abaixo(item 4)
  
-  Para roda o addon individualmente:
   Random : RunScript(script.allinone,moviesrandom=true&amp;limit=10)
   Recents : RunScript(script.allinone,moviesrecents=true&amp;limit=10)
   RunScript(script.allinone,moviesprogress=true&amp;limit=10)
   Estes comandos preenchem as infolabels individualmente para cada tipo e tamb�m define as infolables da lista �nica.
  
Resumindo voc� tem a op��o de usar a lista �nica ou v�rias listas. Todas as infolabels est�o sempre dispon�veis, seja usando lista �nica ou
v�rias.

3. Infolabels lista �nica:
------------------------
Window(Home).Property(*)

AllinOne_DynMovie.%d.Label
AllinOne_DynMovie.%d.Year
AllinOne_DynMovie.%d.Genre
AllinOne_DynMovie.%d.Studio
AllinOne_DynMovie.%d.Plot
AllinOne_DynMovie.%d.PlotOutline
AllinOne_DynMovie.%d.Tagline
AllinOne_DynMovie.%d.Runtime
AllinOne_DynMovie.%d.Fanart
AllinOne_DynMovie.%d.Thumb
AllinOne_DynMovie.%d.Path
AllinOne_DynMovie.%d.Rating
AllinOne_DynMovie.%d.PercentPlayed
AllinOne_DynMovie.%d.Trailer

4. Infolabels individuais para v�rias listas:
--------------------------------------------

AllinOne_MovieRandom.%d.Label
AllinOne_MovieRandom.%d.Year
AllinOne_MovieRandom.%d.Genre
AllinOne_MovieRandom.%d.Studio
AllinOne_MovieRandom.%d.Plot
AllinOne_MovieRandom.%d.PlotOutline
AllinOne_MovieRandom.%d.Tagline
AllinOne_MovieRandom.%d.Runtime
AllinOne_MovieRandom.%d.Fanart
AllinOne_MovieRandom.%d.Thumb
AllinOne_MovieRandom.%d.Path
AllinOne_MovieRandom.%d.Rating
AllinOne_MovieRandom.%d.PercentPlayed
AllinOne_MovieRandom.%d.Trailer

AllinOne_MovieRecents.%d.Label
AllinOne_MovieRecents.%d.Year
AllinOne_MovieRecents.%d.Genre
AllinOne_MovieRecents.%d.Studio
AllinOne_MovieRecents.%d.Plot
AllinOne_MovieRecents.%d.PlotOutline
AllinOne_MovieRecents.%d.Tagline
AllinOne_MovieRecents.%d.Runtime
AllinOne_MovieRecents.%d.Fanart
AllinOne_MovieRecents.%d.Thumb
AllinOne_MovieRecents.%d.Path
AllinOne_MovieRecents.%d.Rating
AllinOne_MovieRecents.%d.PercentPlayed
AllinOne_MovieRecents.%d.Trailer
            
AllinOne_MovieProgress.%d.Label
AllinOne_MovieProgress.%d.Year
AllinOne_MovieProgress.%d.Genre
AllinOne_MovieProgress.%d.Studio
AllinOne_MovieProgress.%d.Plot
AllinOne_MovieProgress.%d.PlotOutline
AllinOne_MovieProgress.%d.Tagline
AllinOne_MovieProgress.%d.Runtime
AllinOne_MovieProgress.%d.Fanart
AllinOne_MovieProgress.%d.Thumb
AllinOne_MovieProgress.%d.Path
AllinOne_MovieProgress.%d.Rating
AllinOne_MovieProgress.%d.PercentPlayed
AllinOne_MovieProgress.%d.Trailer



