import sys, itertools, re, os, random, inspect
import string
if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
from xbmcswift2 import Plugin

plugin = Plugin()
#myMovies = plugin.get_storage('myMovies.json', file_format='json')
#myMovies["clayton"] = "myvalue"
#myMovies.sync()
#simplejson.load(open(file))

# http://mail.python.org/pipermail/python-list/2009-June/596197.html
canResize = "true"

try:
   from PIL import Image
   import urllib, cStringIO
   import ntpath
   from urllib import urlopen
   from urllib import quote
   from cStringIO import StringIO
except:
   canResize = "false"


__addon__        = xbmcaddon.Addon()
__cwd__        = __addon__.getAddonInfo('path')
__addonid__      = __addon__.getAddonInfo('id')
__icon__          = __addon__.getAddonInfo("icon")
profile = xbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
images = os.path.join(profile, 'thumbs')
banners = os.path.join(profile, 'banners')
posters = os.path.join(profile, 'posters')
mvFolder = os.path.join(profile, 'mvFolder')
print mvFolder
__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='plugin.video.cavplusthumbs')
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )

movieBck = os.path.join(__cwd__, 'movieBck.png')

sys.path.append (__resource__)

#settings
runOnStartup = __settings__.getSetting("runOnStartup")

#C:\Users\Clayton\AppData\Roaming\XBMC\addons\script.cavplus
#C:\Users\Clayton\AppData\Roaming\XBMC\userdata\addon_data\script.cavplus\
#urllib.quote(str, safe='~()*!.\'')
if not os.path.exists(profile):
        os.makedirs(profile)
if not os.path.exists(images):
        os.makedirs(images)
if not os.path.exists(banners):
        os.makedirs(banners)
if not os.path.exists(posters):
        os.makedirs(posters)
if not os.path.exists(mvFolder):
        print "mv dont exist default"
        os.makedirs(mvFolder)        

def log(message):
    xbmc.log(msg=message)

def get_crc32( string ):
    string = string.lower()
    bytes = bytearray(string.encode())
    crc = 0xffffffff;
    for b in bytes:
        crc = crc ^ (b << 24)
        for i in range(8):
            if (crc & 0x80000000 ):
                crc = (crc << 1) ^ 0x04C11DB7
            else:
                crc = crc << 1;
        crc = crc & 0xFFFFFFFF
    print ("CRC32=", crc,string)
    return '%08x' % crc


def _resizeImgOff():
   print "off"
   myMovies = plugin.get_storage('myMovies.json', file_format='json')
   hasFile = False
   for i, movie in enumerate(myMovies):
      hasFile = True
      movieId = movie
      finalImg  = myMovies[movie]
      icon = __icon__
      li = xbmcgui.ListItem(movieId, iconImage=icon,thumbnailImage=finalImg)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True) 
   if not hasFile:
      global dialog
      dialog = "true"
      #xbmc.executebuiltin('PlayerControl(Stop)')  
      _resizeImg()
   else :
      xbmcplugin.endOfDirectory(addon_handle) 


def _resizeImg():
   if canResize=="true":
      #files, songs, artists, albums, movies, tvshows, episodes, musicvideos
      xbmcplugin.setContent(addon_handle, 'movies')
      showDialog = 0
      if runCav==0 or dialog=="true":
         showDialog = 1
         message = "Wait ! Checking Thumbnails for Movies..."
         if forceCache=="true":
            message = "Wait ! Checking and Caching Thumbnails for Movies..."
         imgDialog = xbmcgui.DialogProgress()
         imgDialog.create('Progress', 'Wait...')
         #WINDOW_PROGRESS = xbmcgui.Window( 10101 )
         #CANCEL_BUTTON = WINDOW_PROGRESS.getControl( 10 )
         # desable button (bool - True=enabled / False=disabled.)
         #CANCEL_BUTTON.setEnabled( True )
      xbmcgui.Window( 10000 ).setProperty('CAVPLUS_RESIZE', 'true')
      json_params  =  '"params": {"properties": ["title","thumbnail"]}'
      json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies",%s , "id": 1}'% json_params)   
      json_request = unicode(json_request, 'utf-8', errors='ignore')
      json_response = simplejson.loads(json_request)
      print "start cav image resize"
      if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('movies'):
         myMovies = plugin.get_storage('myMovies.json', file_format='json')
         myMoviesCheck = plugin.get_storage('myMoviesCheck.json', file_format='json')
         width = 152
         height = 219
         length = len(json_response['result']['movies'])
         count = 1;
         for movies in json_response['result']['movies']:
             #if imgDialog.iscanceled():
              #  break
             movieId = str(movies["movieid"])
             thumbnail = movies['thumbnail']
             label = movies['label']
             if showDialog==1:
                percent = int((count*100)/length)
                imgDialog.update(percent,message,label)
                count = count+1
             ##print repr(imgDialog.iscanceled())
             
             ##print file
             #thumbCrc = get_crc32("http%3a%2f%2fd3gtl9l2a4fn1j.cloudfront.net%2ft%2fp%2fw500%2f%2fekmykflbqbk3xxwu5mawtcay3yg.jpg")
             #thumbFile = xbmc.getCacheThumbName(file).replace(".tbn","")
             #print thumbFile
             folderName = xbmc.getCacheThumbName(thumbnail).replace(".tbn","")
             folderName = ("%s%s")%(movieId,folderName)
             #folderName = ''.join(c for c in folderName if c in valid_chars)
             #folderName = "%s%s %s"%(movieId,imdb,folderName)
             imagePath = images
             finalImg = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
             finalImg2 = os.path.join(imagePath, '%s_W%sBck.jpg'%(folderName,width))  
             try:
                if (not os.path.isfile(finalImg)  or not folderName in myMoviesCheck ) and thumbnail:
                   #print imagePath
                   thumbnail = quote(thumbnail, safe='~()*!.\'')
                   thumbnail = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/%s'%thumbnail).read())
                   #os.makedirs(imagePath)      
                   img = Image.open(thumbnail)
                   bck = Image.open(movieBck)
                   img2 = img.resize((width, height), Image.ANTIALIAS)
                   #img3 = img.resize((width, height), Image.ANTIALIAS)
                   #img3.paste(bck,(0,0),bck)
                   img2.save(finalImg)
                   #img3.save(finalImg2)
                   myMovies[movieId] = finalImg
                   myMoviesCheck[folderName] = finalImg 
                if thumbnail:
                   icon = movies['thumbnail']
                   li = xbmcgui.ListItem(movieId, iconImage=icon,thumbnailImage=finalImg)
                   xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True)

                if forceCache=="true":
                   imgCache1 = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
                   imgCache1 = quote(imgCache1, safe='~()*!.\'')                   
                   imgCache1 = quote(imgCache1, safe='~()*!.\'') 
                   imgCache1 = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/image://%s/'%imgCache1).read())

             except:
                print thumbnail
                pass
         if showDialog==1:       
            imgDialog.close()
         myMovies.sync()
         myMoviesCheck.sync()
         xbmcplugin.endOfDirectory(addon_handle)
         print "end cav image resize"
      print "clean to use again"   
      xbmcgui.Window( 10000 ).clearProperty('CAVPLUS_RESIZE')
   else:
      icon = __icon__
      li = xbmcgui.ListItem("IMGERROR", iconImage=__icon__,thumbnailImage=__icon__)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True)
      xbmcplugin.endOfDirectory(addon_handle)  


def _resizeImgBannersOff():
   print "off"
   hasFile = False
   myBanners = plugin.get_storage('myBanners.json', file_format='json')
   for i, tvshow in enumerate(myBanners):
      hasFile = True
      tvshowId = tvshow
      finalImg  = myBanners[tvshow]
      icon = __icon__
      li = xbmcgui.ListItem(tvshowId, iconImage=icon,thumbnailImage=finalImg)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True) 
   if not hasFile:
      global dialog
      dialog = "true"
      #xbmc.executebuiltin('PlayerControl(Stop)') 
      _resizeImgBanners()
   else :
      xbmcplugin.endOfDirectory(addon_handle) 

def _resizeImgBanners():
   if canResize=="true":
      xbmcplugin.setContent(addon_handle, 'tvshows')
      showDialog = 0
      if runCav==0 or dialog=="true":
         showDialog = 1
         message = "Wait ! Checking Banners for TvShows..."
         if forceCache=="true":
            message = "Wait ! Checking and Caching Banners for TvShows..."
         imgDialog = xbmcgui.DialogProgress()
         imgDialog.create('Progress', 'Wait...')
      xbmcgui.Window( 10000 ).setProperty('CAVPLUS_RESIZE', 'true')
      json_params  =  '"params": {"properties": ["art"]}'
      json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows",%s , "id": 1}'% json_params)   
      json_request = unicode(json_request, 'utf-8', errors='ignore')
      json_response = simplejson.loads(json_request)
      print "start cav image resize"
      if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('tvshows'):
         myBanners = plugin.get_storage('myBanners.json', file_format='json')
         myBannersCheck = plugin.get_storage('myBannersCheck.json', file_format='json')
         width = 373
         height = 68
         length = len(json_response['result']['tvshows'])
         count = 1;
         for tvshows in json_response['result']['tvshows']:
           try:  
             tvshowsId = str(tvshows["tvshowid"])
             thumbnail = tvshows['art']["banner"]
             label = tvshows['label']
             if showDialog==1:
                percent = int((count*100)/length)
                imgDialog.update(percent,message,label)
                count = count+1
             ##print file
             #thumbCrc = get_crc32("http%3a%2f%2fd3gtl9l2a4fn1j.cloudfront.net%2ft%2fp%2fw500%2f%2fekmykflbqbk3xxwu5mawtcay3yg.jpg")
             #thumbFile = xbmc.getCacheThumbName(file).replace(".tbn","")
             #print thumbFile
             folderName = xbmc.getCacheThumbName(thumbnail).replace(".tbn","")
             folderName = ("%s%s")%(tvshowsId,folderName)
             #folderName = ''.join(c for c in folderName if c in valid_chars)
             #folderName = "%s%s %s"%(movieId,imdb,folderName)
             imagePath = banners
             finalImg = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width)) 
             try:
                if (not os.path.isfile(finalImg)  or not folderName in myBannersCheck) and thumbnail:
                   print imagePath
                   thumbnail = quote(thumbnail, safe='~()*!.\'')
                   thumbnail = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/%s'%thumbnail).read())
                   #os.makedirs(imagePath)      
                   img = Image.open(thumbnail)
                   #bck = Image.open(movieBck)
                   img2 = img.resize((width, height), Image.ANTIALIAS)
                   img2.save(finalImg)
                   myBanners[tvshowsId] = finalImg
                   myBannersCheck[folderName] = finalImg
                if thumbnail:
                   icon = tvshows['art']["banner"]
                   li = xbmcgui.ListItem(tvshowsId, iconImage=icon,thumbnailImage=finalImg)
                   xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True)
                if forceCache=="true":
                   imgCache1 = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
                   imgCache1 = quote(imgCache1, safe='~()*!.\'')                   
                   imgCache1 = quote(imgCache1, safe='~()*!.\'') 
                   imgCache1 = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/image://%s/'%imgCache1).read())

             except:
                print thumbnail
                pass
           except:
              pass
         if showDialog==1:       
            imgDialog.close()
         myBanners.sync()
         myBannersCheck.sync()
         xbmcplugin.endOfDirectory(addon_handle)
         print "end cav banner resize"
      print "clean to use again"   
      xbmcgui.Window( 10000 ).clearProperty('CAVPLUS_RESIZE')
   else:
      icon = __icon__
      li = xbmcgui.ListItem("IMGERROR", iconImage=__icon__,thumbnailImage=__icon__)      
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True)
      xbmcplugin.endOfDirectory(addon_handle) 


def _resizeImgPostersOff():
   print "off"
   hasFile = False
   myPosters= plugin.get_storage('myPosters.json', file_format='json')
   for i, album in enumerate(myPosters):
      hasFile = True
      albumId = album
      finalImg  = myPosters[album]
      icon = __icon__
      li = xbmcgui.ListItem(albumId, iconImage=icon,thumbnailImage=finalImg)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True) 
   if not hasFile:
      global dialog
      dialog = "true"
      #xbmc.executebuiltin('PlayerControl(Stop)') 
      _resizeImgPosters()
   else :
      xbmcplugin.endOfDirectory(addon_handle) 

def _resizeImgPosters():
   if canResize=="true":
      xbmcplugin.setContent(addon_handle, 'albums')
      print runCav
      showDialog = 0
      if runCav==0 or dialog=="true":
         showDialog = 1
         message = "Wait ! Checking Posters for Albums..."
         if forceCache=="true":
            message = "Wait ! Checking and Caching Posters for Albums..."
         imgDialog = xbmcgui.DialogProgress()
         imgDialog.create('Progress', 'Wait...')
      xbmcgui.Window( 10000 ).setProperty('CAVPLUS_RESIZE', 'true')
      json_params  =  '"params": {"properties": ["thumbnail"]}'
      json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "AudioLibrary.GetAlbums",%s , "id": 1}'% json_params)   
      json_request = unicode(json_request, 'utf-8', errors='ignore')
      json_response = simplejson.loads(json_request)
      print "start cav image resize"
      if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('albums'):
         myPosters= plugin.get_storage('myPosters.json', file_format='json')
         myPostersCheck= plugin.get_storage('myPostersCheck.json', file_format='json')
         width = 180
         height = 180
         length = len(json_response['result']['albums'])
         count = 1;
         for albums in json_response['result']['albums']:
             albumsId = str(albums["albumid"])
             thumbnail = albums['thumbnail']
             label = albums['label']
             if showDialog==1:
                percent = int((count*100)/length)
                imgDialog.update(percent,message,label)
                count = count+1
             ##print file
             #thumbCrc = get_crc32("http%3a%2f%2fd3gtl9l2a4fn1j.cloudfront.net%2ft%2fp%2fw500%2f%2fekmykflbqbk3xxwu5mawtcay3yg.jpg")
             #thumbFile = xbmc.getCacheThumbName(file).replace(".tbn","")
             #print thumbFile
             folderName = xbmc.getCacheThumbName(thumbnail).replace(".tbn","")
             folderName = ("%s%s")%(albumsId,folderName)
             #folderName = ''.join(c for c in folderName if c in valid_chars)
             #folderName = "%s%s %s"%(movieId,imdb,folderName)
             imagePath = posters
             finalImg = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width)) 
             try:
                if (not os.path.isfile(finalImg) or not folderName in myPostersCheck) and thumbnail:
                   print imagePath
                   thumbnail = quote(thumbnail, safe='~()*!.\'')
                   thumbnail = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/%s'%thumbnail).read())
                   #os.makedirs(imagePath)      
                   img = Image.open(thumbnail)
                   #bck = Image.open(movieBck)
                   img2 = img.resize((width, height), Image.ANTIALIAS)
                   img2.save(finalImg)
                   myPosters[albumsId] = finalImg
                   myPostersCheck[folderName]= finalImg
                if thumbnail:
                   icon = albums['thumbnail']
                   li = xbmcgui.ListItem(albumsId, iconImage=icon,thumbnailImage=finalImg)
                   xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True)
                if forceCache=="true":
                   imgCache1 = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
                   imgCache1 = quote(imgCache1, safe='~()*!.\'')                   
                   imgCache1 = quote(imgCache1, safe='~()*!.\'') 
                   imgCache1 = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/image://%s/'%imgCache1).read())

             except:
                print thumbnail
                pass
         if showDialog==1:       
            imgDialog.close()
         myPosters.sync()
         myPostersCheck.sync()
         xbmcplugin.endOfDirectory(addon_handle)
         print "end cav posters resize"
      print "clean to use again"   
      xbmcgui.Window( 10000 ).clearProperty('CAVPLUS_RESIZE')
   else:
      icon = __icon__
      li = xbmcgui.ListItem("IMGERROR", iconImage=__icon__,thumbnailImage=__icon__)      
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True)
      xbmcplugin.endOfDirectory(addon_handle)



def _resizeImgMusicVideosOff():
   print "off"
   myMusicVideos = plugin.get_storage('myMusicVideos.json', file_format='json')
   hasFile = False
   for i, movie in enumerate(myMusicVideos):
      hasFile = True
      movieId = movie
      finalImg  = myMusicVideos[movie]
      icon = __icon__
      li = xbmcgui.ListItem(movieId, iconImage=icon,thumbnailImage=finalImg)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True) 
   if not hasFile:
      global dialog
      dialog = "true"
      #xbmc.executebuiltin('PlayerControl(Stop)')  
      _resizeImgMusicVideos()
   else :
      xbmcplugin.endOfDirectory(addon_handle) 


def _resizeImgMusicVideos():
   if canResize=="true":
      #files, songs, artists, albums, movies, tvshows, episodes, musicvideos
      xbmcplugin.setContent(addon_handle, 'movies')
      showDialog = 0
      if runCav==0 or dialog=="true":
         showDialog = 1
         message = "Wait ! Checking Thumbnails for Music Videos..."
         if forceCache=="true":
            message = "Wait ! Checking and Caching Thumbnails for Music Videos..."
         imgDialog = xbmcgui.DialogProgress()
         imgDialog.create('Progress', 'Wait...')
         #WINDOW_PROGRESS = xbmcgui.Window( 10101 )
         #CANCEL_BUTTON = WINDOW_PROGRESS.getControl( 10 )
         # desable button (bool - True=enabled / False=disabled.)
         #CANCEL_BUTTON.setEnabled( True )
      xbmcgui.Window( 10000 ).setProperty('CAVPLUS_RESIZE', 'true')
      json_params  =  '"params": {"properties": ["title","thumbnail"]}'
      json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMusicVideos",%s , "id": 1}'% json_params)   
      json_request = unicode(json_request, 'utf-8', errors='ignore')
      json_response = simplejson.loads(json_request)
      print "start cav music video resize"
      if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('musicvideos'):
         print "1"
         myMusicVideos = plugin.get_storage('myMusicVideos.json', file_format='json')
         myMusicVideosCheck = plugin.get_storage('myMusicVideosCheck.json', file_format='json')
         print "2"
         width = 152
         height = 219
         length = len(json_response['result']['musicvideos'])
         count = 1;
         for musicVideos in json_response['result']['musicvideos']:
             print "3"
             #if imgDialog.iscanceled():
              #  break
             musicVideoId = str(musicVideos["musicvideoid"])
             thumbnail = musicVideos['thumbnail']
             label = musicVideos['label']
             print "4"
             if showDialog==1:
                percent = int((count*100)/length)
                imgDialog.update(percent,message,label)
                count = count+1
             ##print repr(imgDialog.iscanceled())
             
             ##print file
             #thumbCrc = get_crc32("http%3a%2f%2fd3gtl9l2a4fn1j.cloudfront.net%2ft%2fp%2fw500%2f%2fekmykflbqbk3xxwu5mawtcay3yg.jpg")
             #thumbFile = xbmc.getCacheThumbName(file).replace(".tbn","")
             #print thumbFile
             folderName = xbmc.getCacheThumbName(thumbnail).replace(".tbn","")
             folderName = ("%s%s")%(musicVideoId,folderName)
             #folderName = ''.join(c for c in folderName if c in valid_chars)
             #folderName = "%s%s %s"%(movieId,imdb,folderName)
             imagePath = mvFolder
             print "5",mvFolder
             finalImg = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
             print "5.1"
             finalImg2 = os.path.join(imagePath, '%s_W%sBck.jpg'%(folderName,width))
             print "5.2"  
             try:
                if (not os.path.isfile(finalImg)  or not folderName in myMusicVideosCheck ) and thumbnail:
                   #print imagePath
                   print "5.3"
                   thumbnail = quote(thumbnail, safe='~()*!.\'')
                   print "5.4"
                   thumbnail = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/%s'%thumbnail).read())
                   print "5.5"
                   #os.makedirs(imagePath)      
                   img = Image.open(thumbnail)
                   bck = Image.open(movieBck)
                   img2 = img.resize((width, height), Image.ANTIALIAS)
                   #img3 = img.resize((width, height), Image.ANTIALIAS)
                   #img3.paste(bck,(0,0),bck)
                   print "6.0"
                   img2.save(finalImg)
                   #img3.save(finalImg2)
                   print "6.1"
                   myMusicVideos[musicVideoId] = finalImg
                   myMusicVideosCheck[folderName] = finalImg
                   print "7" 
                if thumbnail:
                   print "8"
                   icon = musicVideos['thumbnail']
                   li = xbmcgui.ListItem(musicVideoId, iconImage=icon,thumbnailImage=finalImg)
                   xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True)

                if forceCache=="true":
                   imgCache1 = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
                   imgCache1 = quote(imgCache1, safe='~()*!.\'')                   
                   imgCache1 = quote(imgCache1, safe='~()*!.\'') 
                   imgCache1 = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/image://%s/'%imgCache1).read())

             except:
                print "fail"
                pass
         if showDialog==1:       
            imgDialog.close()
         myMusicVideos.sync()
         myMusicVideosCheck.sync()
         xbmcplugin.endOfDirectory(addon_handle)
         print "end cav image resize"
      print "clean to use again"   
      xbmcgui.Window( 10000 ).clearProperty('CAVPLUS_RESIZE')
   else:
      icon = __icon__
      li = xbmcgui.ListItem("IMGERROR", iconImage=__icon__,thumbnailImage=__icon__)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True)
      xbmcplugin.endOfDirectory(addon_handle)  

def _checkPil():
    try:
       finalImg = os.path.join(__cwd__, 'checkPil.jpg') 
       img = Image.open(movieBck)
       img2 = img.resize((50, 50), Image.ANTIALIAS)
       img2.save(finalImg)
       icon = __icon__
       label = "checkPil_true"
       li = xbmcgui.ListItem(label, iconImage=icon,thumbnailImage=icon)
       url  = icon
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    except:
       icon = __icon__
       label = "checkPil_false"
       li = xbmcgui.ListItem(label, iconImage=icon,thumbnailImage=icon)
       url  = icon
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)   
    xbmcplugin.endOfDirectory(addon_handle)


def _mainMenu():
    icon = __icon__
    xbmcplugin.setContent(addon_handle, 'files')
    li = xbmcgui.ListItem("Movies", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?runImageSize=movies&dialog=true")%base_url
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem("Movies-Force Cache-This can take a long time", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?runImageSize=movies&dialog=true&forceCache=true")%base_url
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem("TvShows", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?runImageSize=banners&dialog=true")%base_url
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem("TvShows-Force Cache-This can take a long time", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?runImageSize=banners&dialog=true&forceCache=true")%base_url
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem("Albums", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?runImageSize=posters&dialog=true")%base_url
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem("Albums-Force Cache-This can take a long time", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?runImageSize=posters&dialog=true&forceCache=true")%base_url
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem("MusicVideos", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?runImageSize=musicvideos&dialog=true")%base_url
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem("MusicVideos-Force Cache-This can take a long time", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?runImageSize=musicvideos&dialog=true&forceCache=true")%base_url
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
    
def get_params():
    print "cavplus called"
    print sys.argv
    
    if len(sys.argv)>=2:
        print "seting args"
        
        paramstring=sys.argv[2]
        paramstring=paramstring.replace('?','')
        params = {}
        if len(paramstring)>0:
           global runCav
           runCav = 1
           params = dict( arg.split( "=" ) for arg in paramstring.split( "&" ) )
           print params
           return params

build_url = "claytonUrl"
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
        

runCav=0

runImageSize = ""
dialog = ""
json = ""
forceCache = ""
params=get_params()
print runCav


try:
    runImageSize=params.get("runImageSize","")
    dialog = params.get("dialog","")
    useJson = params.get("useJson","")
    forceCache = params.get("forceCache","")
except:
    pass
#movies
if runImageSize == "movies":
   print "will resize thumbs"
   if (useJson == "true"):
      _resizeImgOff()
   else :
      _resizeImg()   


#banners
elif runImageSize == "banners":
   print "will resize banners"
   if (useJson == "true"):
      _resizeImgBannersOff()
   else :
      _resizeImgBanners()



#posters
elif runImageSize == "posters":
   print "will resize posters"
   if (useJson == "true"):
      _resizeImgPostersOff()
   else :
      _resizeImgPosters()
      
elif runImageSize == "musicvideos":
   print "will resize thumbs music videos"
   if (useJson == "true"):
      _resizeImgMusicVideosOff()
   else :
      _resizeImgMusicVideos()      



elif runImageSize=="checkPil":
   _checkPil() 

elif runCav==0:
   _mainMenu() 
