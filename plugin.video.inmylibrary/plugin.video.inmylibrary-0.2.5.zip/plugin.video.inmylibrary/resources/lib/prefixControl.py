# -*- coding: utf-8 -*-
import urllib,re,string,sys,os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import time,threading
from xbmcswift2 import Plugin 

myPlugin2 = Plugin()

from resources.lib import dialogAdd
__addon__        = xbmcaddon.Addon()
__cwd__        = __addon__.getAddonInfo('path')
__addonid__      = __addon__.getAddonInfo('id')
__icon__          = __addon__.getAddonInfo("icon")
profile = xbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='plugin.video.inmylibrary')
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )

moviePrefixUpdate = __settings__.getSetting("moviePrefixUpdate")
episodePrefixUpdate = __settings__.getSetting("episodePrefixUpdate")


if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson


def libUpdate():
   print 'will update  prefix ******************************'
   if moviePrefixUpdate == "true":
      print 'will update movie prefix'
      updateMovies() 
   if episodePrefixUpdate == "true":
      print 'will update episode prefix'
      updateEpisodes() 
      
      
def updateMovies():
   deleteFile  = os.path.join(myPlugin2.storage_path,'myMoviesUpdate.json')
   if os.path.exists(deleteFile):
        os.remove(deleteFile)
   makeUpdate = False
   json_filter  = '"filter":{"field": "filename", "operator": "contains", "value": "inmylibrary"}'
   json_params  =  '"params": {"properties": ["file", "title"], %s }' % (json_filter) 
   json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies",%s , "id": 1}'% json_params)   
   json_request = unicode(json_request, 'utf-8', errors='ignore')
   json_response = simplejson.loads(json_request)
   imgDialog = xbmcgui.DialogProgress()
   imgDialog.create('Verificando base de dados', 'Aguarde...')
   if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('movies'):
         myMoviesUpdate = myPlugin2.get_storage('myMoviesUpdate.json', file_format='json')
         length = len(json_response['result']['movies'])
         count = 1
         for movies in json_response['result']['movies']:
            title = movies["title"]
            title = title.encode("UTF-8")
            movieId  = movies["movieid"]
            file = movies["file"]
            prefix = re.findall('\[inmylibrary-(.+?)\]',file)
            if prefix:
               prefix = prefix[0]
               print "prefix in file ",prefix
            else:
               prefix = "IML"
            percent = int((count*100)/length)
            imgDialog.update(percent,"Checando nome do filme",title)
            count = count+1
            
            if re.search("\[%s\]"%prefix,title):
               print "MOVIE HAS PREFIX", repr(title)               
            else:
               print "MOVIE TO INSERT PREFIX",repr(title)
               myMoviesUpdate[movieId] = {}
               myMoviesUpdate[movieId]["title"] = title
               myMoviesUpdate[movieId]["prefix"] = prefix
               makeUpdate = True
            file = movies["file"]
            fileChk = xbmc.getCacheThumbName(file).replace(".tbn","")          
         myMoviesUpdate.sync()
   imgDialog.close()
   if makeUpdate:
      changeMovieName();


def changeMovieName():
   myMoviesUpdate = myPlugin2.get_storage('myMoviesUpdate.json', file_format='json')
   length = len(myMoviesUpdate.keys())
   imgDialog = xbmcgui.DialogProgress()
   imgDialog.create('Alterando título dos filmes', 'Aguarde...')
   for i, id in enumerate(myMoviesUpdate):
      title = myMoviesUpdate[id]["title"]
      print "title to change", repr(title)
      #title  = unicode(title, 'UTF-8').encode('UTF-8')
      title = title.decode("UTF-8")
      prefix = myMoviesUpdate[id]["prefix"]
      changeTitle = ("[%s] %s"%(prefix,title))
      changeTitle = changeTitle.encode("UTF-8")
      percent = int((i*100)/length)
      imgDialog.update(percent,"Alterando título dos filmes",changeTitle)
      print "will change the title",id,repr(title),repr(changeTitle)
      movieId  = int(id)
      json_params  =  '"params": {"movieid":%s,"title":"%s" }' % (movieId,changeTitle) 
      json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.SetMovieDetails",%s , "id": 1}'% json_params)   
      json_request = unicode(json_request, 'utf-8', errors='ignore')
      json_response = simplejson.loads(json_request)
      #print repr(json_response) 
   imgDialog.close()

def updateEpisodes():
   deleteFile  = os.path.join(myPlugin2.storage_path,'myEpisodesUpdate.json')
   if os.path.exists(deleteFile):
        os.remove(deleteFile)
   makeUpdate = False
   json_filter  = '"filter":{"field": "filename", "operator": "contains", "value": "inmylibrary"}'
   json_params  =  '"params": {"properties": ["file", "title"], %s }' % (json_filter) 
   json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes",%s , "id": 1}'% json_params)   
   json_request = unicode(json_request, 'utf-8', errors='ignore')
   json_response = simplejson.loads(json_request)
   imgDialog = xbmcgui.DialogProgress()
   imgDialog.create('Verificando base de dados', 'Aguarde...')
   if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('episodes'):
         myEpisodesUpdate = myPlugin2.get_storage('myEpisodesUpdate.json', file_format='json')
         length = len(json_response['result']['episodes'])
         count = 1;
         for episodes in json_response['result']['episodes']:
            title = episodes["title"]
            title = title.encode("UTF-8")
            episodeId  = episodes["episodeid"]
            
            file = episodes["file"]
            prefix = re.findall('\[inmylibrary-(.+?)\]',file)
            if prefix:
               prefix = prefix[0]
               print "prefix in file ",prefix
            else:
               prefix = "IML"
            
            percent = int((count*100)/length)
            imgDialog.update(percent,"Checando nome do episódio",title)
            count = count+1
            
            if re.search("\[%s\]"%prefix,title):
               print "EPISODIO HAS PREFIX", repr(title)               
            else:
               print "EPISODIO TO INSERT PREFIX",repr(title)
               myEpisodesUpdate[episodeId] = {}
               myEpisodesUpdate[episodeId]["title"] = title
               myEpisodesUpdate[episodeId]["prefix"] = prefix
               makeUpdate = True         
         myEpisodesUpdate.sync()
   imgDialog.close()
   if makeUpdate:
      changeEpisodeName();


def changeEpisodeName():
   myEpisodesUpdate = myPlugin2.get_storage('myEpisodesUpdate.json', file_format='json')
   length = len(myEpisodesUpdate.keys())
   imgDialog = xbmcgui.DialogProgress()
   imgDialog.create('Alterando título dos episódios', 'Aguarde...')
   for i, id in enumerate(myEpisodesUpdate):
      title = myEpisodesUpdate[id]["title"]
      title = title.decode("UTF-8")
      prefix = myEpisodesUpdate[id]["prefix"]
      changeTitle = ("[%s] %s"%(prefix,title))
      changeTitle = changeTitle.encode("UTF-8")
      percent = int((i*100)/length)
      imgDialog.update(percent,"Alterando título dos episódios",changeTitle)
      print "will change the title",id,repr(title),repr(changeTitle)
      episodeId  = int(id)
      json_params  =  '"params": {"episodeid":%s,"title":"%s" }' % (episodeId,changeTitle) 
      json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.SetEpisodeDetails",%s , "id": 1}'% json_params)   
      json_request = unicode(json_request, 'utf-8', errors='ignore')
      json_response = simplejson.loads(json_request)
      #print repr(json_response) 
   imgDialog.close()
                               