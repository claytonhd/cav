import urllib,re,string,sys,os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import time,threading
from xbmcswift2 import Plugin 
myPlugin2 = Plugin()
__addon__        = xbmcaddon.Addon()
__cwd__        = __addon__.getAddonInfo('path')
__addonid__      = __addon__.getAddonInfo('id')
__icon__          = __addon__.getAddonInfo("icon")
profile = xbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='plugin.video.brasilanimes')
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )

mySearch = myPlugin2.get_storage('search.json', file_format='json')
myFavorites = myPlugin2.get_storage('favorites.json', file_format='json')

baseUrl = "http://anitube.xpg.uol.com.br/"
categoryUrl = "http://anitube.xpg.uol.com.br/categories"

def MAIN():
    icon = __icon__
    print  "anitube ----------------------------------------------------"
    xbmcplugin.setContent(addon_handle, 'files')
    li = xbmcgui.ListItem("HOME", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=1&url=%s")%(myPlugin,baseUrl)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    li = xbmcgui.ListItem("CATEGORIAS", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=4&url=%s")%(myPlugin,categoryUrl)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    li = xbmcgui.ListItem("SEARCH", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=6&cat=anitube")%(myPlugin)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem("FAVORITOS", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=11&cat=anitube")%(myPlugin)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)  
    
    xbmcplugin.endOfDirectory(addon_handle)  

def getHome(url):
    xbmcplugin.setContent(addon_handle, 'episodes')
    link = OPENURL(url)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    #print link
     
    match = re.findall('li class="mainList"> <div class="videoThumb"> <a href="(.+?)" title="(.+?)"><img src="(.+?)" alt="(.+?)" id="(.+?)" /></a> </div> <div class="videoTitle">',link)
    #match = re.findall('<div class="movie_pic"><a href="(.+?)"  target=".+?">    <img src="(.+?)".+?target="_self">(.+?)</a>.+?">Genre:  <a href=".+?>(.+?)</a>.+?<br/>Views: <span>(.+?)</span>.+?(.+?)votes.+?score:(.+?)</div>',link)
    #match = re.findall('<div class="movie_pic"><a href="(.+?)"  target=".+?">    <img src="(.+?)".+?target="_self">(.+?)</a>.+?">Genre:  <a href=".+?>(.+?)</a>.+?<br/>Views: <span>(.+?)</span>.+?(.+?)votes.+?score:(.+?)</div>',link)
    totalLinks = len(match)
    for url,title,img,alt,id in match:
       
       li = xbmcgui.ListItem(alt, thumbnailImage=img)
       url  = ("%s?mode=2&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    xbmcplugin.endOfDirectory(addon_handle)   

def getLinkHome(url):
    link = OPENURL(url)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    #match = re.findall('src="http://anitube.xpg.uol.com.br/embed/(.+?)" frameborder="0" scrolling="no"></iframe>',link)
    match = re.findall('src="http://anitubebr.xpg.uol.com.br/embed/(.+?)" frameborder="0" scrolling="no"></iframe>',link)
    idFile =  match[0]
    linkFile  = "http://anitube.xpg.uol.com.br/nuevo/econfig.php?key=%s"%idFile
    link = OPENURL(linkFile)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    #http://anitube.xpg.uol.com.br/nuevo/econfig.php?key=7e4ed8971cb4ec0c8c4b
    #<file>http://chi08.vid.anitu.be/26_QRqAY6qr2CaXpbUEQmA/1398632509/69936.mp4</file><filehd>http://chi08.vid.anitu.be/avJaRTsOqFrMdS_ozD9znw/1398632509/69936_hd.mp4</filehd>
    file = re.findall('<file>(.+?)</file>',link)
    fileHd = re.findall('<filehd>(.+?)</filehd>',link)
    fileHtml = re.findall('<html5>(.+?)</html5>',link)
    img = re.findall('<image>(.+?)</image>',link)
    img = img[0]
    print img
    if file:
       url  = file[0]
       li = xbmcgui.ListItem("Normal", thumbnailImage=img)
       url  = ("%s?mode=3&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li) 
    if fileHd:
       url  = fileHd[0]
       li = xbmcgui.ListItem("HD", thumbnailImage=img)
       url  = ("%s?mode=3&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li) 
    if fileHtml:
       url  = fileHtml[0]
       li = xbmcgui.ListItem("Html", thumbnailImage=img)
       url  = ("%s?mode=3&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li)       
    xbmcplugin.endOfDirectory(addon_handle) 


def getCategory(url):
    contextMenuItems = []
    xbmcplugin.setContent(addon_handle, 'episodes')
    link = OPENURL(url)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    
    li = xbmcgui.ListItem("PAGINA")
    #li.setInfo(infoLabels={"title": "PROCURAR PAGINA"})
    url  = ("%s?mode=14")%myPlugin
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    pagination  = re.findall('<ul id="pagination-flickr">(.+?)</ul>',link)
    next = re.findall('<li><a href="(.+?)">(.+?)</a></li>',pagination[0])     
    for url,page in next:
       print url,page
       li = xbmcgui.ListItem(page)
       url  = ("%s?mode=4&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
       
    
    match = re.findall('<li class="mainList"> <div class="videoThumb"> <a href="(.+?)" title="(.+?)"><img src="(.+?)" alt="(.+?)" /></a> </div> <div class="catTitle">',link)
    for url,view,img,title in match:
       contextMenuItems = []
       li = xbmcgui.ListItem(title, thumbnailImage=img)
       contextMenuItems.append(("Adicionar aos Favoritos",'XBMC.RunScript(%s,%s,?mode=%s&url=%s&name=%s&thumbnail=%s&cat=anitube)'% ("plugin.video.brasilanimes",1,"10",url,title,img)))
       url  = ("%s?mode=5&url=%s")%(myPlugin,url)
       print url
       li.setInfo(type="Video", infoLabels={"title": title, "plot": view})   
       li.addContextMenuItems(contextMenuItems, replaceItems=True)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)    
    
    xbmcplugin.endOfDirectory(addon_handle)     

def getPage():
   print "ask for page"
   dialog = xbmcgui.Dialog()
   page = dialog.input('INSIRA A PAGINA',"", type=xbmcgui.INPUT_ALPHANUM)
   if page:
      try:
         int(page)
         url = "http://anitubebr.xpg.uol.com.br/categories/page/%s"%page
         getCategory(url)
      except:
         print "error"
def getCategoryItems(url):
    xbmcplugin.setContent(addon_handle, 'episodes')
    link = OPENURL(url)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    print link
    
    category = re.findall('http://anitubebr.xpg.uol.com.br/categories/(.+?)/(.+?)/(.*)',url)
    category0 = re.findall('http://anitubebr.xpg.uol.com.br/categories/(.+?)/(.*)',url)
    if len(category)>0 :
       url2  = ("%s?mode=15&cod=%s&name=%s")%(myPlugin,category[0][0],category[0][2])
    else:
       url2  = ("%s?mode=15&cod=%s&name=%s")%(myPlugin,category0[0][0],category0[0][1])
    li = xbmcgui.ListItem("PAGINA")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url2,listitem=li, isFolder=True) 
    
    
    pagination  = re.findall('<ul id="pagination-flickr">(.+?)</ul>',link)
    next = re.findall('<li><a href="(.+?)">(.+?)</a></li>',pagination[0])     
    for url,page in next:
       #print url,page
       li = xbmcgui.ListItem(page)
       url  = ("%s?mode=5&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)  
    
     
    match = re.findall('li class="mainList"> <div class="videoThumb"> <a href="(.+?)" title="(.+?)"><img src="(.+?)" alt="(.+?)" id="(.+?)" /></a> </div> <div class="videoTitle">',link)
    totalLinks = len(match)
    for url,title,img,alt,id in match:
       li = xbmcgui.ListItem(alt, thumbnailImage=img)
       url  = ("%s?mode=2&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    xbmcplugin.endOfDirectory(addon_handle)

def getPageItem(cod,name):
   print "ask for page",cod, name
   dialog = xbmcgui.Dialog()
   page = dialog.input('INSIRA A PAGINA',"", type=xbmcgui.INPUT_ALPHANUM)
   if page:
      try:
         int(page)
         url = "http://anitubebr.xpg.uol.com.br/categories/%s/%s/%s"%(cod,page,name)
         getCategoryItems(url)
      except:
         print "error"

def searchAnimeClean():                                         
   file  = os.path.join(myPlugin2.storage_path,'search.json')
   if os.path.exists(file):
        os.remove(file)
   

def searchAnime():
    li = xbmcgui.ListItem("Search")
    url  = ("%s?mode=8")%myPlugin
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    li = xbmcgui.ListItem("Apagar Todos")
    url  = ("%s?mode=9")%myPlugin
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    for i, search in enumerate(mySearch):
      keySearch = search
      url  = mySearch[search]
      icon = __icon__
      li = xbmcgui.ListItem(search)
      url  = ("%s?mode=7&url=%s")%(myPlugin,url)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    xbmcplugin.endOfDirectory(addon_handle)
def searchAnime2():
    keyboard = xbmc.Keyboard("", 'Search', False)
    keyboard.doModal()
    
    if keyboard.isConfirmed():
         query = keyboard.getText()
         url = "http://anitube.xpg.uol.com.br/search/basic/1/?sort=title&search_type=videos&search_id="+query
         if not query in mySearch :
            mySearch[query] = url
            mySearch.sync()
         searchAnimeItems(url)

def searchAnimeItems(url):
    xbmcplugin.setContent(addon_handle, 'episodes')
    link = OPENURL(url)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    print link
    pagination  = re.findall('<ul id="pagination-flickr">(.+?)</ul>',link)
    next = re.findall('<li><a href="(.+?)">(.+?)</a></li>',pagination[0])     
    for url,page in next:
       print url,page
       li = xbmcgui.ListItem(page)
       url  = ("%s?mode=7&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    
    match = re.findall('<li class="mainList"> <div class="videoThumb"> <a href="(.+?)" title="(.+?)"><img src="(.+?)" id="(.+?)" alt="(.+?)" /></a> </div> <div class="videoTitle">',link) 
    totalLinks = len(match)
    for url,title,img,id,alt in match:
       li = xbmcgui.ListItem(alt, thumbnailImage=img)
       url  = ("%s?mode=2&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    xbmcplugin.endOfDirectory(addon_handle)



def playLink(url):
    listitem = xbmcgui.ListItem(path=url)
    xbmc.Player( xbmc.PLAYER_CORE_MPLAYER ).play(url, listitem)

def getUrl(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link


def OPENURL(url, mobile = False, q = False, verbose = True, timeout = 10, cookie = None, data = None, cookiejar = False, log = True, headers = [], type = '',ua = False):
    import urllib2 
    UserAgent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
    if ua: UserAgent = ua
    try:
        if log:
            print "MU-Openurl = " + url
        if cookie and not cookiejar:
            import cookielib
            cookie_file = os.path.join(os.path.join(datapath,'Cookies'), cookie+'.cookies')
            cj = cookielib.LWPCookieJar()
            if os.path.exists(cookie_file):
                try: cj.load(cookie_file,True)
                except: cj.save(cookie_file,True)
            else: cj.save(cookie_file,True)
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        elif cookiejar:
            import cookielib
            cj = cookielib.LWPCookieJar()
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        else:
            opener = urllib2.build_opener()
        if mobile:
            opener.addheaders = [('User-Agent', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7')]
        else:
            opener.addheaders = [('User-Agent', UserAgent)]
        for header in headers:
            opener.addheaders.append(header)
        if data:
            if type == 'json': 
                import json
                data = json.dumps(data)
                opener.addheaders.append(('Content-Type', 'application/json'))
            else: data = urllib.urlencode(data)
            response = opener.open(url, data, timeout)
        else:
            response = opener.open(url, timeout=timeout)
        if cookie and not cookiejar:
            cj.save(cookie_file,True)
        link=response.read()
        response.close()
        opener.close()
        #link = net(UserAgent).http_GET(url).content
        link=link.replace('&#39;',"'").replace('&quot;','"').replace('&amp;',"&").replace("&#39;","'").replace('&lt;i&gt;','').replace("#8211;","-").replace('&lt;/i&gt;','').replace("&#8217;","'").replace('&amp;quot;','"').replace('&#215;','x').replace('&#038;','&').replace('&#8216;','').replace('&#8211;','').replace('&#8220;','').replace('&#8221;','').replace('&#8212;','')
        link=link.replace('%3A',':').replace('%2F','/')
        if q: q.put(link)
        return link
    except Exception as e:
        if verbose:
            xbmc.executebuiltin("XBMC.Notification(Sorry!,Source Website is Down,3000,"+elogo+")")
        xbmc.log('***********Website Error: '+str(e)+'**************', xbmc.LOGERROR)
        import traceback
        traceback.print_exc()
        link ='website down'
        if q: q.put(link)
        return link

    
def get_params():
    print sys.argv
    param=[]
    paramstring=sys.argv[2]
    
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

        
params=get_params()
myPlugin = sys.argv[0]
addon_handle = int(sys.argv[1])
mode= None
url =None

print sys.argv
           