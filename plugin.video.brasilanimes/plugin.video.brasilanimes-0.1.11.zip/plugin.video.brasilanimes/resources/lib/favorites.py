import urllib,re,string,sys,os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import time,threading
from xbmcswift2 import Plugin 
import urllib
from urllib import quote
import myResolver
import urllib2
from BeautifulSoup import BeautifulSoup, NavigableString, Tag
import unicodedata as ud
import anitube,mvonline,mgserieson, myResolver,favorites 

myPlugin2 = Plugin() 
__addon__        = xbmcaddon.Addon()
__cwd__        = __addon__.getAddonInfo('path')
__addonid__      = __addon__.getAddonInfo('id')
__icon__          = __addon__.getAddonInfo("icon")
profile = xbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='plugin.video.brasilanimes')
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )


mySearchMgSeriesOn = myPlugin2.get_storage('searchMgSeriesOn.json', file_format='json')
myFavoritesMgSeriesOn = myPlugin2.get_storage('favoritesMgSeriesOn.json', file_format='json')
mySearchAnitube = myPlugin2.get_storage('searchAnitube.json', file_format='json')
myFavoritesAnitube = myPlugin2.get_storage('favoritesAnitube.json', file_format='json')


def addFavorites(url,name,thumbnail,cat):
    print url,name,thumbnail,cat
    tempDict = {}
    if cat=="mgserieson":
       tempDict = myFavoritesMgSeriesOn
    elif cat=="anitube":
       print "create anitube favorite"
       tempDict = myFavoritesAnitube
    favId = xbmc.getCacheThumbName(name).replace(".tbn","")
    name = str(name)
    print "favId", favId
    tempDict[favId] = {}
    tempDict[favId]["name"] = name
    tempDict[favId]["url"] = url
    tempDict[favId]["thumbnail"] = thumbnail
    tempDict.sync() 

def getFavorites(cat):
    tempDict = {}
    if cat=="mgserieson":
       tempDict = myFavoritesMgSeriesOn
       mode  = 102
    elif cat=="anitube":
       tempDict = myFavoritesAnitube
       mode = 5
    
    url  = ("%s?mode=13&cat=%s")%(myPlugin,cat)
    li = xbmcgui.ListItem("APAGAR TODOS")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=False) 
    for i, favorite in enumerate(tempDict):
      name   = tempDict[favorite]["name"]
      url  = tempDict[favorite]["url"]
      thumbnail  = tempDict[favorite]["thumbnail"]
      icon = __icon__
      url  = ("%s?mode=%s&url=%s")%(myPlugin,mode,url)
      
      li = xbmcgui.ListItem(name,thumbnailImage=thumbnail)
      contextMenuItems = []
      contextMenuItems.append(("Deletar",'XBMC.RunScript(%s,%s,?mode=%s&url=%s&name=%s&thumbnail=%s&cat=%s)'% ("plugin.video.brasilanimes",1,"12",url,favorite,thumbnail,cat)))
      li.addContextMenuItems(contextMenuItems, replaceItems=True)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    xbmcplugin.endOfDirectory(addon_handle)

def delFavorites(name,cat):
    tempDict = {}
    if cat=="mgserieson":
       tempDict = myFavoritesMgSeriesOn
       mode  = 102
    elif cat=="anitube":
       tempDict = myFavoritesAnitube
    
    del tempDict[name]
    tempDict.sync() 
    xbmc.sleep(500)
    xbmc.executebuiltin("XBMC.Container.Refresh")

def favoriteClean(cat):                                         
    if cat=="mgserieson":
       file  = os.path.join(myPlugin2.storage_path,'favoritesMgSeriesOn.json')
    elif cat=="anitube":
       file  = os.path.join(myPlugin2.storage_path,'favoritesAnitube.json')
    if os.path.exists(file):
        os.remove(file)
    xbmc.sleep(500)
    xbmc.executebuiltin("XBMC.Container.Refresh")


#*****************************************************************************************SEARCH********************************************************************************

def menuSearch(cat):
    li = xbmcgui.ListItem("SEARCH")
    url  = ("%s?mode=8&cat=%s")%(myPlugin,cat)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    li = xbmcgui.ListItem("APAGAR TODOS")
    url  = ("%s?mode=9&cat=%s")%(myPlugin,cat)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    tempDict = {}
    if cat=="mgserieson":
       tempDict = mySearchMgSeriesOn
       mode  = 106
    elif cat=="anitube":
       tempDict = mySearchAnitube
       mode = 7
    for i, search in enumerate(tempDict):
      keySearch = search
      url  = tempDict[search]['url']
      name = tempDict[search]['name']
      icon = __icon__
      li = xbmcgui.ListItem(name)
      url  = ("%s?mode=%s&url=%s")%(myPlugin,mode,url)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    xbmcplugin.endOfDirectory(addon_handle)

def reqSearch(cat):
    keyboard = xbmc.Keyboard("", 'Search', False)
    keyboard.doModal()
    
    tempDict = {}
    if cat=="mgserieson":
       tempDict = mySearchMgSeriesOn
    elif cat=="anitube":
       tempDict = mySearchAnitube
    if keyboard.isConfirmed():
         query = keyboard.getText()
         if cat == "mgserieson":
            query  = query.replace(" ","+")
            url = "http://megaseriesonlinehd.com/?s="+query
         elif cat == "anitube":
            url = "http://anitube.xpg.uol.com.br/search/basic/1/?sort=title&search_type=videos&search_id="+query
         
         searchId = xbmc.getCacheThumbName(query).replace(".tbn","")
         if not searchId in tempDict :
            tempDict[searchId] = {}
            tempDict[searchId]["name"] = query
            tempDict[searchId]["url"] = url
            tempDict.sync()
         
         if cat == "mgserieson":
            mgserieson.getHome(url,"RESULTADODABUSCA")
         elif cat == "anitube":
            anitube.searchAnimeItems(url)
def sarchClean(cat):                                         
    if cat=="mgserieson":
       file  = os.path.join(myPlugin2.storage_path,'searchMgSeriesOn.json')
    elif cat=="anitube":
       file  = os.path.join(myPlugin2.storage_path,'searchAnitube.json')
    if os.path.exists(file):
        os.remove(file)
    xbmc.sleep(500)
    xbmc.executebuiltin("XBMC.Container.Refresh")
         
    
def get_params():
    print sys.argv
    param=[]
    paramstring=sys.argv[2]
    
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

        
params=get_params()
myPlugin = sys.argv[0]
addon_handle = int(sys.argv[1])
mode= None
url =None

print sys.argv
           