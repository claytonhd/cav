from time import strptime, mktime, gmtime, strftime, localtime
from operator import itemgetter
import itertools
import sys, itertools, re, os, random, inspect
import copy
import string
if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
from urllib import urlopen
from urllib import quote
from cStringIO import StringIO

# http://mail.python.org/pipermail/python-list/2009-June/596197.html


__addon__        = xbmcaddon.Addon()
__cwd__        = __addon__.getAddonInfo('path')
__addonid__      = __addon__.getAddonInfo('id')
__icon__          = __addon__.getAddonInfo("icon")
profile = xbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='script.cavplus')
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )

sys.path.append (__resource__)


#C:\Users\Clayton\AppData\Roaming\XBMC\addons\script.cavplus
#C:\Users\Clayton\AppData\Roaming\XBMC\userdata\addon_data\script.cavplus\
#urllib.quote(str, safe='~()*!.\'')


def log(message):
    xbmc.log(msg=message)
class Main:
    def __init__( self ):
        log("iniciou o CAV PLUS")
        #xbmc.executebuiltin('Action(3dmodesbs)')        
        self._parse_argv()
        if self.SLEEPTIMER:
           self._setSleepTimer()
        if self.SLEEPCANCEL:
           self._cancelAlarm()
        if self.SHOWHIDEWATCHED:
           self._toggleWatched()
        if self.VIEWMODE:
           self._setViewMode()
        if self.FULLPLAYLIST:
           self._smart_playlist_full()
        if self.PLAYTRAILER:
           self._playTrailer()    
        if self.SHOWPLOT:
           self._showPlot()
        if self.SHOWPLOTTRAILER:
           self._showPlotTrailer()  
        if self.TOPMENU:
           self._topMenu()
        if self.MENUHV:
           self._menuHV()   
        if self.SMARTSUBMENU:
           self._smartSubMenu() 
        if self.UNWATCHEDEPISODES:
           self._unWatchedEpisodes()
        if self.ALLEPISODES:
           self._allEpisodes()
        if self.ALLEPISODESWATCH and self.ALLEPISODESWATCHVALUE and not self.ALLSEASONSWATCHVALUE:
           self._allEpisodesWatch()
        if self.ALLEPISODESWATCH and self.ALLEPISODESWATCHVALUE and self.ALLSEASONSWATCHVALUE:
           self._allSeasonsWatch()   
        if self.SEASONTVSHOW and self.SEASONSEASON:
           self._seasonEpisodes() 
        if self.EXCECBUILTIN:
           self._execBuiltin()   
        if self.PLAYLISTPLAY:
           self._playlistplay() 
        if self.PROFILE:
           self._loadProfile() 
        if self.CLOSEAPP:
           self._closeAppName()                  
    def _parse_argv( self ):
        #get all params send from skinner
        try:
            params = dict( arg.split( "=" ) for arg in sys.argv[ 1 ].split( "&" ) )
        except:
            params = {}  
        self.EXCECBUILTIN = params.get( "execbultin", "" )
        self.SLEEPTIMER = params.get( "sleeptimer", "" )
        self.SLEEPTYPE = params.get( "sleeptype", "" )
        self.SLEEPCANCEL = params.get( "sleepcancel", "" )
        self.SHOWHIDEWATCHED = params.get( "showhidewatched", "" ) 
        self.VIEWMODE = params.get( "viewmode", "" )
        self.FULLPLAYLIST = params.get( "playlist", "" )
        self.PLAYTRAILER = params.get( "playtrailer", "" )
        self.SHOWPLOT = params.get( "showplot", "" )
        self.SHOWPLOTTRAILER = params.get( "showplottrailer", "" )
        self.TOPMENU = params.get( "topmenu", "" )
        self.MENUHV = params.get( "menuhv", "" )
        self.SMARTSUBMENU = params.get( "smartsubmenu", "" ) 
        self.UNWATCHEDEPISODES = params.get( "unwatchedepisodes", "" )
        self.ALLEPISODES = params.get( "allepisodes", "" )
        self.ALLEPISODESWATCH = params.get( "allepisodeswatch", "" )
        self.ALLEPISODESWATCHVALUE = params.get( "allepisodeswatchvalue", "" )
        self.ALLSEASONSWATCHVALUE = params.get( "allseasonswatchvalue", "" )
        self.SEASONTVSHOW = params.get( "seasontvshow", "" )
        self.SEASONSEASON = params.get( "seasonseason", "" )
        self.PLAYLISTPLAY = params.get( "playlistplay", "" )
        self.PROFILE = params.get("profile","")
        self.CLOSEAPP = params.get("closeapp","")
        log(self.VIEWMODE)
        
    def _execBuiltin( self ):
        xbmc.executebuiltin('%s'%self.EXCECBUILTIN)
    
    
    def _setSleepTimer(self):
        intSleepTimer = int(self.SLEEPTIMER)
        if self.SLEEPTIMER != "0" and self.SLEEPTYPE:
           twoDigits = ("0" + self.SLEEPTIMER)[-2:]
           xbmc.executebuiltin('XBMC.AlarmClock(SleepTimer,XBMC.%s,%s)'%(self.SLEEPTYPE,twoDigits)) 
        else: 
           xbmc.executebuiltin('XBMC.CancelAlarm(SleepTimer)')
    def _loadProfile(self):
        xbmc.executebuiltin('LoadProfile(%s)'%self.PROFILE)       
    
    def _toggleWatched( self ):
        if xbmc.getCondVisibility( 'Container.Content(Movies)' ) or xbmc.getCondVisibility( 'Container.Content(tvshows)' ) or xbmc.getCondVisibility( 'Container.Content(Seasons)' ) or xbmc.getCondVisibility( 'Container.Content(Episodes)' ):
           xbmc.executebuiltin('SendClick(14)')
           log("rodou")      
    
    def _playTrailer( self ):
        if xbmc.getCondVisibility( 'Container.Content(Movies)' ):
           path = xbmc.getInfoLabel('ListItem.Trailer')
           xbmc.executebuiltin('SetFocus(9930)')
           xbmc.executebuiltin('PlayMedia(%s,1)'%path)
    def _showPlot( self ):
        log("showplot")
        if xbmc.getCondVisibility( 'Container.Content(Movies)' ):
           path = xbmc.getInfoLabel('ListItem.Trailer')
           title = xbmc.getInfoLabel('ListItem.Title')
           plot = xbmc.getInfoLabel('ListItem.Plot')
           mydisplay = MainClass(plot = plot,title=title)
           mydisplay.doModal()
           del mydisplay         
    def _showPlotTrailer( self ):
        if xbmc.getCondVisibility( 'Container.Content(Movies)' ):
           path = xbmc.getInfoLabel('ListItem.Trailer')
           title = xbmc.getInfoLabel('ListItem.Title')
           plot = xbmc.getInfoLabel('ListItem.Plot')
           mydisplay = MainClass(plot = plot,title=title)
           mydisplay.doModal()
           del mydisplay
           xbmc.executebuiltin('SetFocus(9930)')
           xbmc.executebuiltin('PlayMedia(%s,1)'%path)
    def _topMenu( self ):
           xbmc.executebuiltin('Skin.ToggleSetting(kiosk)')
           xbmc.executebuiltin('Skin.Reset(kiosksmart)')
           xbmc.executebuiltin('Skin.Reset(kiosksmart)')
    def _smartSubMenu( self ):
           xbmc.executebuiltin('Skin.ToggleSetting(nosmartsub)')
    
    def _menuHV( self ):
        if xbmc.getCondVisibility( 'SubString(skin.string(menu),vertical)' ):
           xbmc.executebuiltin('Skin.SetString(menu,horizontal)')      
        else:
           xbmc.executebuiltin('Skin.SetString(menu,vertical)') 
        xbmc.executebuiltin('ActivateWindow(home)')    
    def _setViewMode( self ):
       smallViewMode = self.VIEWMODE.lower()
       if smallViewMode == "next":
          xbmc.executebuiltin('Container.NextViewMode')
       elif smallViewMode == "previous":
          xbmc.executebuiltin('Container.PreviousViewMode') 

    def _smart_playlist_full(self):    
        myFileName = xbmc.translatePath("special://profile/playlists/mixed/cavsmart.xsp")
        cavFile = open(myFileName, "w")
        cavFile.write(self.FULLPLAYLIST)
        cavFile.close()
        xbmc.executebuiltin("XBMC.ActivateWindow(music,special://temp/voxsmart.xsp)")
    def _playlistplay(self):
        playlist = ""
        if self.PLAYLISTPLAY == "video":
           playlist = xbmc.PlayList(1)
        elif self.PLAYLISTPLAY == "audio":
           playlist = xbmc.PlayList(0)
        if playlist:
           xbmc.Player().play(playlist)
    def _unWatchedEpisodes(self):
        log("playlist insert")
        playlist = xbmc.PlayList(1)
        #playlist.clear()
        tvshowid  = int(self.UNWATCHEDEPISODES)
        json_filter  = '"filter":{"field": "playcount", "operator": "is", "value": "0"}'
        json_params  =  '"params": {"sort": {"order": "ascending", "method": "episode"},"properties": ["episode", "season", "playcount","file"], "tvshowid":%s,%s }' % (tvshowid,json_filter) 
        json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes",%s , "id": 1}'% json_params)   
        json_request = unicode(json_request, 'utf-8', errors='ignore')
        json_response = simplejson.loads(json_request)
        if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('episodes'):
           for episodesList in json_response['result']['episodes']:
              #if episodesList.has_key('playcount'):
              playcount = int(episodesList['playcount'])
              if playcount==0:
                 file = episodesList['file']
                 fileReplace = file.replace("\\","/")
                 episodeid = int(episodesList['episodeid'])
                 xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.Add","params":{"playlistid":1, "item": {"episodeid": %d}}}'%episodeid) 
                 #playlist.add(url=file)
    def _allEpisodes(self):
        log("playlist insert")
        playlist = xbmc.PlayList(1)
        #playlist.clear()
        tvshowid  = int(self.ALLEPISODES)
        json_filter  = '"filter":{"field": "playcount", "operator": "true", "value": ""}'
        json_params  =  '"params": {"sort": {"order": "ascending", "method": "episode"},"properties": ["episode", "season", "playcount","file"], "tvshowid":%s,%s }' % (tvshowid,json_filter) 
        json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes",%s , "id": 1}'% json_params)   
        json_request = unicode(json_request, 'utf-8', errors='ignore')
        json_response = simplejson.loads(json_request)
        if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('episodes'):
           for episodesList in json_response['result']['episodes']:
              #if episodesList.has_key('playcount'):
              playcount = int(episodesList['playcount'])
              file = episodesList['file']
              fileReplace = file.replace("\\","/")
              episodeid = int(episodesList['episodeid'])
              xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.Add","params":{"playlistid":1, "item": {"episodeid": %d}}}'%episodeid) 
              #playlist.add(url=file)
    def _seasonEpisodes(self):
        log("playlist insert")
        playlist = xbmc.PlayList(1)
        #playlist.clear()
        tvshowid  = int(self.SEASONTVSHOW)
        season  = self.SEASONSEASON
        json_filter  = '"filter":{"field": "season", "operator": "is", "value": "%s"}'%season
        json_params  =  '"params": {"sort": {"order": "ascending", "method": "episode"},"properties": ["episode", "season", "playcount","file"], "tvshowid":%s,%s }' % (tvshowid,json_filter) 
        json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes",%s , "id": 1}'% json_params)   
        json_request = unicode(json_request, 'utf-8', errors='ignore')
        json_response = simplejson.loads(json_request)
        if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('episodes'):
           for episodesList in json_response['result']['episodes']:
              #if episodesList.has_key('playcount'):
              playcount = int(episodesList['playcount'])
              file = episodesList['file']
              fileReplace = file.replace("\\","/")
              episodeid = int(episodesList['episodeid'])
              xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.Add","params":{"playlistid":1, "item": {"episodeid": %d}}}'%episodeid) 
              #playlist.add(url=file)
    def _allEpisodesWatch(self):
        tvshowid  = int(self.ALLEPISODESWATCH)
        value  = self.ALLEPISODESWATCHVALUE
        log(self.ALLEPISODESWATCH)
        log(self.ALLEPISODESWATCHVALUE)
        json_filter  = '"filter":{"field": "playcount", "operator": "is", "value": ""}'
        json_params  =  '"params": {"sort": {"order": "ascending", "method": "episode"},"properties": ["playcount"], "tvshowid":%s,%s }' % (tvshowid,json_filter) 
        json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes",%s , "id": 1}'% json_params)   
        json_request = unicode(json_request, 'utf-8', errors='ignore')
        json_response = simplejson.loads(json_request)
        print 'Episodes Response', repr(json_response)
        if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('episodes'):
           log('get playcount')
           for episodesList in json_response['result']['episodes']:
              playcount = int(episodesList['playcount'])
              episodeid = int(episodesList['episodeid'])
              setPlaycount = 1
              if not value or value=="0":
                 log("value %s"%value)
                 setPlaycount = 0
              if setPlaycount != playcount:   
                 xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":%d,"playcount":%d},"id":1}'% (episodeid,setPlaycount)) 
    def _allSeasonsWatch(self):
        tvshowid  = int(self.ALLEPISODESWATCH)
        value  = self.ALLEPISODESWATCHVALUE
        season = self.ALLSEASONSWATCHVALUE
        log(self.ALLEPISODESWATCH)
        log(self.ALLEPISODESWATCHVALUE)
        json_filter  = '"filter":{"field": "season", "operator": "is", "value": "%s"}'%season
        json_params  =  '"params": {"sort": {"order": "ascending", "method": "episode"},"properties": ["playcount"], "tvshowid":%s,%s }' % (tvshowid,json_filter) 
        json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes",%s , "id": 1}'% json_params)   
        json_request = unicode(json_request, 'utf-8', errors='ignore')
        json_response = simplejson.loads(json_request)
        print 'Seasons Response', repr(json_response)
        if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('episodes'):
           log('get playcount')
           for episodesList in json_response['result']['episodes']:
              playcount = int(episodesList['playcount'])
              episodeid = int(episodesList['episodeid'])
              setPlaycount = 1
              if not value or value=="0":
                 log("value %s"%value)
                 setPlaycount = 0
              if setPlaycount != playcount:   
                 xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":%d,"playcount":%d},"id":1}'% (episodeid,setPlaycount)) 
    
    def _closeAppName( self ):
        os.system("TASKKILL /F /IM %s"%self.CLOSEAPP)
              
ACTION_PREVIOUS_MENU = 10
ACTION_SELECT_ITEM = 7
ACTION_NAV_BACK = 92
class MainClass(xbmcgui.Window):
  def __init__(self,*args, **kwargs ):
    addonpath = __addon__.getAddonInfo('path')
    log(addonpath)
    background = '%s\\background.png'%addonpath
    log(background)
    self.addControl(xbmcgui.ControlImage(0,0,1280,720, background))
    self.strActionInfo = xbmcgui.ControlLabel(60, 60, 1080, 200, '', font="Font_23", textColor='0xFFFFFAF0')
    self.addControl(self.strActionInfo)
    self.title = kwargs[ "title" ]
    self.strActionInfo.setLabel(self.title)
    self.strActionInfo = xbmcgui.ControlTextBox(60, 150, 1160, 550, textColor='0xFFFFFFFF')
    self.addControl(self.strActionInfo)
    self.plot = kwargs[ "plot" ]
    self.strActionInfo.setText(self.plot)
    
 
  def onAction(self, action):
    if action == ACTION_PREVIOUS_MENU or action == ACTION_NAV_BACK:
      self.close()
    if action == ACTION_SELECT_ITEM:
      popup = ChildClass()
      popup .doModal()
      del popup
 
class ChildClass(xbmcgui.Window):
  def __init__(self):
    self.addControl(xbmcgui.ControlImage(0,0,800,600, 'background.png'))
    self.strActionInfo = xbmcgui.ControlLabel(200, 60, 200, 200, '', 'font14', '0xFFBBFFBB')
    self.addControl(self.strActionInfo)
    self.strActionInfo.setLabel('Push BACK to return to the first window')
    self.strActionInfo = xbmcgui.ControlLabel(240, 200, 200, 200, '', 'font13', '0xFFFFFF99')
    self.addControl(self.strActionInfo)
    self.strActionInfo.setLabel(self.plot)
       
  def onAction(self, action):
    if action == ACTION_PREVIOUS_MENU:
       self.close()    
      

                                       
if ( __name__ == "__main__" ):
    log('script version %s started' % __addonversion__)
    Main()
    del Main