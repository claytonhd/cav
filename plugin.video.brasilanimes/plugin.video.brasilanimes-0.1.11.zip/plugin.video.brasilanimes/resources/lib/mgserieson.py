import urllib,re,string,sys,os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import time,threading
from xbmcswift2 import Plugin 
import urllib
from urllib import quote
import myResolver
import urllib2
from BeautifulSoup import BeautifulSoup, NavigableString, Tag
import unicodedata as ud


myPlugin2 = Plugin() 
__addon__        = xbmcaddon.Addon()
__cwd__        = __addon__.getAddonInfo('path')
__addonid__      = __addon__.getAddonInfo('id')
__icon__          = __addon__.getAddonInfo("icon")
profile = xbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='plugin.video.brasilanimes')
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )


mySearch = myPlugin2.get_storage('searchMgSeriesOn.json', file_format='json')
myFavorites = myPlugin2.get_storage('favoritesMgSeriesOn.json', file_format='json')

home = "http://megaseriesonlinehd.com/"
desenho = "http://megaseriesonlinehd.com/index.php/category/desenhos/"

def MAIN():
    icon = __icon__
    print  "anitube ----------------------------------------------------"
    xbmcplugin.setContent(addon_handle, 'files')
    url = home
    li = xbmcgui.ListItem("SERIADOS ATUALIZADOS", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=101&url=%s&type=SeriadosAtualizados")%(myPlugin,url)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    url = desenho
    li = xbmcgui.ListItem("DESENHOS", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=101&url=%s&type=Desenhos")%(myPlugin,url)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem("SEARCH", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=6&cat=mgserieson")%(myPlugin)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem("FAVORITOS", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=11&cat=mgserieson")%(myPlugin)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)  
    
    xbmcplugin.endOfDirectory(addon_handle)  





def getHome(url,type1):
    print "mega series online get home"
    xbmcplugin.setContent(addon_handle, 'files')
    link = OPENURL(url)
    #link = re.sub(r'[^\x00-\x7F]+','x', link)
    #link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    print "url *************************************", url
    soup = BeautifulSoup(link)
    try:
       getPagination = str(soup.find(attrs={'class':'wp-pagenavi'}).find(attrs={'class':'nextpostslink'})['href'])
    except:
       getPagination = ""
       pass
    pageType = type1
    if type1 == "SeriadosAtualizados":
       pageType = "Completos"
    
    if getPagination:
       li = xbmcgui.ListItem("Proxima")
       url  = ("%s?mode=101&url=%s&type=%s")%(myPlugin,getPagination,pageType)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    print "pagination", getPagination
    
    getClass  = soup.findAll(attrs={'class' :"seriados-bloco"})
    for cat in getClass:
       myCat = cat.h4.contents
       mySpan = (cat.h4.find('span').text)
       print "myspan",repr(mySpan)
       try:
          mySpan = str(mySpan).replace(" ","")
       except:
          mySpan = "nulo"
       print repr(myCat[1]),mySpan
       myCat1 = str(myCat[1]).replace("\xe2","").replace("\t","").replace("\x80\x9c","").replace("\x80\x9d","").replace(" ","")
       print "myCat1", repr(myCat)
       print "type1*********************************",type1,myCat1
       if len(myCat)>0 and (myCat1== type1 or mySpan==type1):
          print "found it !!!!!"
          print "category",cat
          myMovies = cat.find('ul').findAll('li')
          print "movies",repr(myMovies)
          for movie in myMovies:
             movie = str(movie)
             movie = movie.replace("&amp;","")
             #print "my movies *********", movie
             title = re.findall('<div class="title-serie">(.+?)</div>',movie)
             title = title[0]
             img = re.findall('<img src="(.+?)"',movie)
             img = img[0]
             url  = re.findall('<a href="(.+?)"',movie)
             url = url[0]
             url  = ("%s?mode=102&url=%s")%(myPlugin,url)
             
             li = xbmcgui.ListItem(title,thumbnailImage=img)
             contextMenuItems = []
             contextMenuItems.append(("Adicionar aos Favoritos",'XBMC.RunScript(%s,%s,?mode=%s&url=%s&name=%s&thumbnail=%s&cat=mgserieson)'% ("plugin.video.brasilanimes",1,"10",url,title,img)))
             li.addContextMenuItems(contextMenuItems, replaceItems=True)
             xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    xbmcplugin.endOfDirectory(addon_handle)     
    #print "getClass", getClass
    #print "test",getClass.h4
    #print "test2",getClass.h4.find(attrs={'class' :"title-bloco"})
    #print "test3",getClass.find('span').string

def getSeasons(url):
    print "url *************************************", url
    xbmcplugin.setContent(addon_handle, 'files')
    link = OPENURL(url)
    #link = re.sub(r'[^\x00-\x7F]+','x', link)
    #link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    
    soup = BeautifulSoup(link)
    #print soup
    getImg = soup.find(attrs={'class':"capapost"}).find('img')['src']
    getInfo = str(soup.find(attrs={'class':"descricao"}).find('p').string) 
    print getImg,repr(getInfo)
    
    getClass  = soup.find(attrs={'id' :"series-player"}).findAll('li')
    for season in getClass:
       id = season.find('span').string
       id = str(id)
       print "season",id,season
       strSeason = str(season)
       
       match = re.findall('<a target="_blank" href="(.+?)">(.+?)</a>',strSeason)
       parsing  = 1
       if not match :
          parsing = 2
          match  = re.findall('<a href="(.+?)" target="_blank">(.+?)</a><br />',strSeason)
       for url,title in match: 
          url = str(url)
          url  = url.replace("&amp;","&")
          print url
          title = title
          cleanTitle = re.compile("Assistir", re.IGNORECASE)
          title = cleanTitle.sub("", title)
          title = title.replace('\xe2\x80\x93','').lstrip()
          title = ('%s %s')%(title,id)
          li = xbmcgui.ListItem(title,thumbnailImage=getImg)
          li.setInfo(type="Video", infoLabels={"title": title, "plot": getInfo,"playcount":0,"tagline":getInfo})  
          url  = ("%s?mode=103&url=%s")%(myPlugin,url)
          xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    xbmcplugin.endOfDirectory(addon_handle)       

def getLinks(url,d):
    #http://megaseriesonlinehd.com/player/?v=fb81inqpq79q&d=cKcgCYSbBB
    print "url *************************************", url
    xbmcplugin.setContent(addon_handle, 'files')
    link = OPENURL(url)
    #link = re.sub(r'[^\x00-\x7F]+','x', link)
    #link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    
    soup = BeautifulSoup(link)
    
    getClass = soup.find(attrs={'id':"filmes"}).findAll('li')
    print "getClass",getClass
    for links in getClass:
       myLinks = str(links['class'])
       print "myLinks",repr(myLinks)
       if myLinks != "principal-codigo" and myLinks != "principal-code":
          url = str(links.find('iframe')['src'])
          if re.search("dropvideo",url) and d:
             url = "http://www.dropvideo.com/embed/%s/"%d
          li = xbmcgui.ListItem(myLinks) 
          url  = ("%s?mode=104&url=%s")%(myPlugin,url)
          xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=False) 
    
    if not getClass:
       getClass = soup.find(attrs={'id':"filmes"}).findAll('center')
       print "getClass",getClass
       strGetClass = str(getClass)
       match = re.findall('name="Player" src="(.+?)"',strGetClass)
       for url in match:
          li = xbmcgui.ListItem("Link") 
          url = str(url)
          if re.search("dropvideo",url) and d:
             url = "http://www.dropvideo.com/embed/%s/"%d
          url  = ("%s?mode=104&url=%s")%(myPlugin,url)
          xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=False) 
    xbmcplugin.endOfDirectory(addon_handle)     



def playLink(url):
    listitem = xbmcgui.ListItem(path=url)
    xbmc.Player( xbmc.PLAYER_CORE_MPLAYER ).play(url, listitem)

def getUrl(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link


def reqSearch():
    keyboard = xbmc.Keyboard("", 'Search', False)
    keyboard.doModal()
    
    if keyboard.isConfirmed():
         query = keyboard.getText()
         query  = query.replace(" ","+")
         url = "http://megaseriesonlinehd.com/?s="+query
         searchId = xbmc.getCacheThumbName(query).replace(".tbn","")
         if not searchId in mySearch :
            mySearch[searchId] = {}
            mySearch[searchId]["name"] = url
            mySearch[searchId]["url"] = url
            mySearch.sync()
         getHome(url,"RESULTADODABUSCA")


def OPENURL(url, mobile = False, q = False, verbose = True, timeout = 10, cookie = None, data = None, cookiejar = False, log = True, headers = [], type = '',ua = False):
    import urllib2 
    UserAgent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
    if ua: UserAgent = ua
    try:
        if log:
            print "MU-Openurl = " + url
        if cookie and not cookiejar:
            import cookielib
            cookie_file = os.path.join(os.path.join(datapath,'Cookies'), cookie+'.cookies')
            cj = cookielib.LWPCookieJar()
            if os.path.exists(cookie_file):
                try: cj.load(cookie_file,True)
                except: cj.save(cookie_file,True)
            else: cj.save(cookie_file,True)
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        elif cookiejar:
            import cookielib
            cj = cookielib.LWPCookieJar()
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        else:
            opener = urllib2.build_opener()
        if mobile:
            opener.addheaders = [('User-Agent', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7')]
        else:
            opener.addheaders = [('User-Agent', UserAgent)]
        for header in headers:
            opener.addheaders.append(header)
        if data:
            if type == 'json': 
                import json
                data = json.dumps(data)
                opener.addheaders.append(('Content-Type', 'application/json'))
            else: data = urllib.urlencode(data)
            response = opener.open(url, data, timeout)
        else:
            response = opener.open(url, timeout=timeout)
        if cookie and not cookiejar:
            cj.save(cookie_file,True)
        link=response.read()
        response.close()
        opener.close()
        #link = net(UserAgent).http_GET(url).content
        link=link.replace('&#39;',"'").replace('&quot;','"').replace('&amp;',"&").replace("&#39;","'").replace('&lt;i&gt;','').replace("#8211;","-").replace('&lt;/i&gt;','').replace("&#8217;","'").replace('&amp;quot;','"').replace('&#215;','x').replace('&#038;','&').replace('&#8216;','').replace('&#8211;','').replace('&#8220;','').replace('&#8221;','').replace('&#8212;','')
        link=link.replace('%3A',':').replace('%2F','/')
        if q: q.put(link)
        return link
    except Exception as e:
        if verbose:
            xbmc.executebuiltin("XBMC.Notification(Sorry!,Source Website is Down,3000,"+elogo+")")
        xbmc.log('***********Website Error: '+str(e)+'**************', xbmc.LOGERROR)
        import traceback
        traceback.print_exc()
        link ='website down'
        if q: q.put(link)
        return link

    
def get_params():
    print sys.argv
    param=[]
    paramstring=sys.argv[2]
    
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

        
params=get_params()
myPlugin = sys.argv[0]
addon_handle = int(sys.argv[1])
mode= None
url =None

print sys.argv
           