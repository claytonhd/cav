from time import strptime, mktime, gmtime, strftime, localtime
from operator import itemgetter
import itertools
import sys, itertools, re, os, random, inspect
import copy
if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson
import xbmc, xbmcgui, xbmcaddon
# http://mail.python.org/pipermail/python-list/2009-June/596197.html
import _strptime

__addon__        = xbmcaddon.Addon()
__addonid__      = __addon__.getAddonInfo('id')
__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='script.cavplus')



def log(message):
    xbmc.log(msg=message)
class Main:
    def __init__( self ):
        log("iniciou o aceplus")
        #xbmc.executebuiltin('Action(3dmodesbs)')        
        self._parse_argv()
        if self.SLEEPTIMER:
           self._setSleepTimer()
        if self.SLEEPCANCEL:
           self._cancelAlarm()
        if self.SHOWHIDEWATCHED:
           self._toggleWatched()
        if self.VIEWMODE:
           self._setViewMode()
        
    def _parse_argv( self ):
        #get all params send from skinner
        try:
            params = dict( arg.split( "=" ) for arg in sys.argv[ 1 ].split( "&" ) )
        except:
            params = {}
        self.SLEEPTIMER = params.get( "sleeptimer", "" )
        self.SLEEPTYPE = params.get( "sleeptype", "" )
        self.SLEEPCANCEL = params.get( "sleepcancel", "" )
        self.SHOWHIDEWATCHED = params.get( "showhidewatched", "" )
        self.VIEWMODE = params.get( "viewmode", "" )
        
    def _setSleepTimer(self):
        intSleepTimer = int(self.SLEEPTIMER)
        if self.SLEEPTIMER != "0" and self.SLEEPTYPE:
           twoDigits = ("0" + self.SLEEPTIMER)[-2:]
           xbmc.executebuiltin('XBMC.AlarmClock(SleepTimer,XBMC.%s,%s)'%(self.SLEEPTYPE,twoDigits)) 
        else: 
           xbmc.executebuiltin('XBMC.CancelAlarm(SleepTimer)')
           
    def _toggleWatched( self ):
        if xbmc.getCondVisibility( 'Container.Content(Movies)' ) or xbmc.getCondVisibility( 'Container.Content(tvshows)' ) or xbmc.getCondVisibility( 'Container.Content(Seasons)' ) or xbmc.getCondVisibility( 'Container.Content(Episodes)' ):
           xbmc.executebuiltin('SendClick(14)')     
    
    def _setViewMode( self ):
       smallViewMode = self.VIEWMODE.lower()
       if smallViewMode == "next":
          xbmc.executebuiltin('Container.NextViewMode')
       elif smallViewMode == "previous":
          xbmc.executebuiltin('Container.PreviousViewMode')                                            
if ( __name__ == "__main__" ):
    log('script version %s started' % __addonversion__)
    Main()