import sys, itertools, re, os, random, inspect
import string
if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
from xbmcswift2 import Plugin

plugin = Plugin()

# http://mail.python.org/pipermail/python-list/2009-June/596197.html
canResize = "true"

try:
   from PIL import Image
   import urllib, cStringIO
   import ntpath
   from urllib import urlopen
   from urllib import quote
   from cStringIO import StringIO
except:
   canResize = "false"


__addon__        = xbmcaddon.Addon()
__cwd__        = __addon__.getAddonInfo('path')
__addonid__      = __addon__.getAddonInfo('id')
__icon__          = __addon__.getAddonInfo("icon")

profile = xbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
images = os.path.join(profile, 'thumbs')
banners = os.path.join(profile, 'banners')
posters = os.path.join(profile, 'posters')
mvFolder = os.path.join(profile, 'mvFolder')

movieBck = os.path.join(__cwd__, 'movieBck.png')

__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='plugin.video.cavplusthumbs')
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )

runOnStartup = __settings__.getSetting("runOnStartup")
runOnUpdate = __settings__.getSetting("runOnUpdate")
forceCache = __settings__.getSetting("cacheOnStartup")
forceCacheUpdate = __settings__.getSetting("cacheOnUpdate")

sys.path.append (__resource__)
#C:\Users\Clayton\AppData\Roaming\XBMC\addons\script.cavplus
#C:\Users\Clayton\AppData\Roaming\XBMC\userdata\addon_data\script.cavplus\
#urllib.quote(str, safe='~()*!.\'')
if not os.path.exists(profile):
        os.makedirs(profile)
if not os.path.exists(images):
        os.makedirs(images)
if not os.path.exists(banners):
        os.makedirs(banners)
if not os.path.exists(mvFolder):
        print "mv dont exist service"
        os.makedirs(mvFolder)         

valid_chars = "-_.() %s%s" % (string.ascii_letters, string.digits)
#print valid_chars

class Main():
   def __init__( self ):
     self.Monitor = Widgets_Monitor(update_listitems = self._updateLibrary)
     xbmcgui.Window( 10000 ).clearProperty('CAVPLUS_SERVICE')
     xbmc.sleep(2000)
     xbmcgui.Window( 10000 ).setProperty('CAVPLUS_SERVICE', 'true')
     xbmc.sleep(500)
     self._daemon()
   def _updateLibrary(self,database):
      print "cavplus monitor update working1 "
      global forceCache
      forceCache = "false"
      runOnUpdate = __settings__.getSetting("runOnUpdate")
      print runOnUpdate
      if database == "video" and runOnUpdate=="true":
         _resizeImg()
         _resizeImgBanners()
         _resizeImgMusicVideos()   
      elif  database == "music" and runOnUpdate=="true":
         _resizeImgPosters
   def _daemon( self ):
        # keep running until xbmc exits or another instance is started
        while (not xbmc.abortRequested) and xbmcgui.Window( 10000 ).getProperty('CAVPLUS_SERVICE') == 'true':      
            xbmc.sleep(1000)
            #print "thumbs running"
        if xbmc.abortRequested:
            log('script stopped: xbmc quit')
        else:
            log('script stopped: new script instance started')           
     



class Widgets_Monitor(xbmc.Monitor):
    def __init__(self,*args, **kwargs):
        xbmc.Monitor.__init__(self)
        self.update_listitems = kwargs['update_listitems']

    def onDatabaseUpdated(self, database):
        self.update_listitems(database)



def log(message):
    xbmc.log(msg=message)



def get_crc32( string ):
    string = string.lower()
    bytes = bytearray(string.encode())
    crc = 0xffffffff;
    for b in bytes:
        crc = crc ^ (b << 24)
        for i in range(8):
            if (crc & 0x80000000 ):
                crc = (crc << 1) ^ 0x04C11DB7
            else:
                crc = crc << 1;
        crc = crc & 0xFFFFFFFF
    print ("CRC32=", crc,string)
    return '%08x' % crc

    

def _resizeImg():
   if canResize=="true":
      imgDialog = xbmcgui.DialogProgress()
      imgDialog.create('Progress', 'Wait...')
      xbmcgui.Window( 10000 ).setProperty('CAVPLUS_RESIZE', 'true')
      xbmc.executebuiltin('Notification(Wait, this can take a while,3000,%s)'%__icon__)
      json_params  =  '"params": {"properties": ["title","thumbnail"]}'
      json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies",%s , "id": 1}'% json_params)   
      json_request = unicode(json_request, 'utf-8', errors='ignore')
      json_response = simplejson.loads(json_request)
      print "start cav image resize"
      if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('movies'):
         myMovies = plugin.get_storage('myMovies.json', file_format='json')
         myMoviesCheck = plugin.get_storage('myMoviesCheck.json', file_format='json')
         width = 152
         height = 219
         length = len(json_response['result']['movies'])
         count = 1;
         for movies in json_response['result']['movies']:
             movieId = str(movies["movieid"])
             thumbnail = movies['thumbnail']
             label = movies['label']
             percent = int((count*100)/length)
             imgDialog.update(percent,"Wait! Creating Thumbnails for Movies...",label)
             count = count+1
             ##print file
             #thumbCrc = get_crc32("http%3a%2f%2fd3gtl9l2a4fn1j.cloudfront.net%2ft%2fp%2fw500%2f%2fekmykflbqbk3xxwu5mawtcay3yg.jpg")
             #thumbFile = xbmc.getCacheThumbName(file).replace(".tbn","")
             #print thumbFile
             folderName = xbmc.getCacheThumbName(thumbnail).replace(".tbn","")
             folderName = ("%s%s")%(movieId,folderName)
             #folderName = ''.join(c for c in folderName if c in valid_chars)
             #folderName = "%s%s %s"%(movieId,imdb,folderName)
             imagePath = images
             finalImg = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
             finalImg2 = os.path.join(imagePath, '%s_W%sBck.jpg'%(folderName,width))  
             try:
                if (not os.path.isfile(finalImg) or not folderName in myMoviesCheck ) and thumbnail:
                   #print imagePath
                   thumbnail = quote(thumbnail, safe='~()*!.\'')
                   thumbnail = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/%s'%thumbnail).read())
                   #os.makedirs(imagePath)      
                   img = Image.open(thumbnail)
                   bck = Image.open(movieBck)
                   img2 = img.resize((width, height), Image.ANTIALIAS)
                   #img3 = img.resize((width, height), Image.ANTIALIAS)
                   #img3.paste(bck,(0,0),bck)
                   img2.save(finalImg)
                   #img3.save(finalImg2)
                   myMovies[movieId] = finalImg
                   myMoviesCheck[folderName] = finalImg 
                if forceCache=="true" or forceCacheUpdate=="true":
                   imgCache1 = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
                   imgCache1 = quote(imgCache1, safe='~()*!.\'')                   
                   imgCache1 = quote(imgCache1, safe='~()*!.\'') 
                   imgCache1 = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/image://%s/'%imgCache1).read())   
                   
             except:
                print thumbnail
                pass
         myMovies.sync()
         myMoviesCheck.sync()
         imgDialog.close()
         print "end cav image resize"
      print "clean to use again"   
      xbmcgui.Window( 10000 ).clearProperty('CAVPLUS_RESIZE')
   else:
      icon = __icon__

def _resizeImgBanners():
   if canResize=="true":
      xbmcplugin.setContent(addon_handle, 'tvshows')
      showDialog = 1
      imgDialog = xbmcgui.DialogProgress()
      imgDialog.create('Progress', 'Wait...')
      xbmcgui.Window( 10000 ).setProperty('CAVPLUS_RESIZE', 'true')
      json_params  =  '"params": {"properties": ["art"]}'
      json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows",%s , "id": 1}'% json_params)   
      json_request = unicode(json_request, 'utf-8', errors='ignore')
      json_response = simplejson.loads(json_request)
      print "start cav image resize"
      if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('tvshows'):
         myBanners = plugin.get_storage('myBanners.json', file_format='json')
         myBannersCheck = plugin.get_storage('myBannersCheck.json', file_format='json')
         width = 373
         height = 68
         length = len(json_response['result']['tvshows'])
         count = 1;
         for tvshows in json_response['result']['tvshows']:
           try:  
             tvshowsId = str(tvshows["tvshowid"])
             thumbnail = tvshows['art']["banner"]
             label = tvshows['label']
             percent = int((count*100)/length)
             imgDialog.update(percent,"Wait ! Creating Banners for TvShows...",label)
             count = count+1
             folderName = xbmc.getCacheThumbName(thumbnail).replace(".tbn","")
             folderName = ("%s%s")%(tvshowsId,folderName)
             imagePath = banners
             finalImg = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width)) 
             try:
                if (not os.path.isfile(finalImg)  or not folderName in myBannersCheck) and thumbnail:
                   print imagePath
                   thumbnail = quote(thumbnail, safe='~()*!.\'')
                   thumbnail = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/%s'%thumbnail).read())
                   #os.makedirs(imagePath)      
                   img = Image.open(thumbnail)
                   #bck = Image.open(movieBck)
                   img2 = img.resize((width, height), Image.ANTIALIAS)
                   img2.save(finalImg)
                   myBanners[tvshowsId] = finalImg
                   myBannersCheck[folderName] = finalImg
                if forceCache=="true" or forceCacheUpdate=="true":
                   imgCache1 = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
                   imgCache1 = quote(imgCache1, safe='~()*!.\'')                   
                   imgCache1 = quote(imgCache1, safe='~()*!.\'') 
                   imgCache1 = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/image://%s/'%imgCache1).read())    
             except:
                print thumbnail
                pass
           except:
              pass     
         myBanners.sync()
         myBannersCheck.sync()
         imgDialog.close()
         print "end cav banner resize"
      print "clean to use again"   
      xbmcgui.Window( 10000 ).clearProperty('CAVPLUS_RESIZE')
   else:
      icon = __icon__
      li = xbmcgui.ListItem("IMGERROR", iconImage=__icon__,thumbnailImage=__icon__)      
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True)
      xbmcplugin.endOfDirectory(addon_handle) 

def _resizeImgPosters():
   if canResize=="true":
      xbmcplugin.setContent(addon_handle, 'albums')
      showDialog = 1
      imgDialog = xbmcgui.DialogProgress()
      imgDialog.create('Progress', 'Wait...')
      xbmcgui.Window( 10000 ).setProperty('CAVPLUS_RESIZE', 'true')
      json_params  =  '"params": {"properties": ["thumbnail"]}'
      json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "AudioLibrary.GetAlbums",%s , "id": 1}'% json_params)   
      json_request = unicode(json_request, 'utf-8', errors='ignore')
      json_response = simplejson.loads(json_request)
      print "start cav image resize"
      if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('albums'):
         myPosters= plugin.get_storage('myPosters.json', file_format='json')
         myPostersCheck= plugin.get_storage('myPostersCheck.json', file_format='json')
         width = 180
         height = 180
         length = len(json_response['result']['albums'])
         count = 1;
         for albums in json_response['result']['albums']:
             albumsId = str(albums["albumid"])
             thumbnail = albums['thumbnail']
             label = albums['label']
             if showDialog==1:
                percent = int((count*100)/length)
                imgDialog.update(percent,"Wait ! Creating Posters for Albums...",label)
                count = count+1
             ##print file
             #thumbCrc = get_crc32("http%3a%2f%2fd3gtl9l2a4fn1j.cloudfront.net%2ft%2fp%2fw500%2f%2fekmykflbqbk3xxwu5mawtcay3yg.jpg")
             #thumbFile = xbmc.getCacheThumbName(file).replace(".tbn","")
             #print thumbFile
             folderName = xbmc.getCacheThumbName(thumbnail).replace(".tbn","")
             folderName = ("%s%s")%(albumsId,folderName)
             #folderName = ''.join(c for c in folderName if c in valid_chars)
             #folderName = "%s%s %s"%(movieId,imdb,folderName)
             imagePath = posters
             finalImg = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width)) 
             try:
                if (not os.path.isfile(finalImg) or not folderName in myPostersCheck) and thumbnail:
                   print imagePath
                   thumbnail = quote(thumbnail, safe='~()*!.\'')
                   thumbnail = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/%s'%thumbnail).read())
                   #os.makedirs(imagePath)      
                   img = Image.open(thumbnail)
                   #bck = Image.open(movieBck)
                   img2 = img.resize((width, height), Image.ANTIALIAS)
                   img2.save(finalImg)
                   myPosters[albumsId] = finalImg
                   myPostersCheck[folderName]= finalImg
                if forceCache=="true" or forceCacheUpdate=="true":
                   imgCache1 = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
                   imgCache1 = quote(imgCache1, safe='~()*!.\'')                   
                   imgCache1 = quote(imgCache1, safe='~()*!.\'') 
                   imgCache1 = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/image://%s/'%imgCache1).read()) 
             except:
                print thumbnail
                pass     
         myPosters.sync()
         myPostersCheck.sync()
         imgDialog.close()
         print "end cav posters resize"
      print "clean to use again"   
      xbmcgui.Window( 10000 ).clearProperty('CAVPLUS_RESIZE')
   else:
      icon = __icon__
      li = xbmcgui.ListItem("IMGERROR", iconImage=__icon__,thumbnailImage=__icon__)      
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True)
      xbmcplugin.endOfDirectory(addon_handle)
      
def _resizeImgMusicVideos():
   if canResize=="true":
      #files, songs, artists, albums, movies, tvshows, episodes, musicvideos
      xbmcplugin.setContent(addon_handle, 'movies')
      showDialog = 1
      message = "Wait ! Checking Thumbnails for Music Videos..."
      imgDialog = xbmcgui.DialogProgress()
      imgDialog.create('Progress', 'Wait...')
      xbmcgui.Window( 10000 ).setProperty('CAVPLUS_RESIZE', 'true')
      json_params  =  '"params": {"properties": ["title","thumbnail"]}'
      json_request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMusicVideos",%s , "id": 1}'% json_params)   
      json_request = unicode(json_request, 'utf-8', errors='ignore')
      json_response = simplejson.loads(json_request)
      print "start cav music video resize"
      if json_response.has_key('result') and json_response['result'] != None and json_response['result'].has_key('musicvideos'):
         myMusicVideos = plugin.get_storage('myMusicVideos.json', file_format='json')
         myMusicVideosCheck = plugin.get_storage('myMusicVideosCheck.json', file_format='json')
         width = 152
         height = 219
         length = len(json_response['result']['musicvideos'])
         count = 1;
         for musicVideos in json_response['result']['musicvideos']:
             #if imgDialog.iscanceled():
              #  break
             musicVideoId = str(musicVideos["musicvideoid"])
             thumbnail = musicVideos['thumbnail']
             label = musicVideos['label']
             if showDialog==1:
                percent = int((count*100)/length)
                imgDialog.update(percent,message,label)
                count = count+1
             ##print repr(imgDialog.iscanceled())
             
             ##print file
             #thumbCrc = get_crc32("http%3a%2f%2fd3gtl9l2a4fn1j.cloudfront.net%2ft%2fp%2fw500%2f%2fekmykflbqbk3xxwu5mawtcay3yg.jpg")
             #thumbFile = xbmc.getCacheThumbName(file).replace(".tbn","")
             #print thumbFile
             folderName = xbmc.getCacheThumbName(thumbnail).replace(".tbn","")
             folderName = ("%s%s")%(musicVideoId,folderName)
             #folderName = ''.join(c for c in folderName if c in valid_chars)
             #folderName = "%s%s %s"%(movieId,imdb,folderName)
             imagePath = mvFolder
             finalImg = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
             finalImg2 = os.path.join(imagePath, '%s_W%sBck.jpg'%(folderName,width)) 
             try:
                if (not os.path.isfile(finalImg)  or not folderName in myMusicVideosCheck ) and thumbnail:
                   #print imagePath
                   thumbnail = quote(thumbnail, safe='~()*!.\'')
                   thumbnail = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/%s'%thumbnail).read())
                   #os.makedirs(imagePath)      
                   img = Image.open(thumbnail)
                   bck = Image.open(movieBck)
                   img2 = img.resize((width, height), Image.ANTIALIAS)
                   #img3 = img.resize((width, height), Image.ANTIALIAS)
                   #img3.paste(bck,(0,0),bck)
                   img2.save(finalImg)
                   #img3.save(finalImg2)
                   myMusicVideos[musicVideoId] = finalImg
                   myMusicVideosCheck[folderName] = finalImg

                if forceCache=="true":
                   imgCache1 = os.path.join(imagePath, '%s_W%s.jpg'%(folderName,width))
                   imgCache1 = quote(imgCache1, safe='~()*!.\'')                   
                   imgCache1 = quote(imgCache1, safe='~()*!.\'') 
                   imgCache1 = StringIO(urlopen('http://xbmc@127.0.0.1:8080/image/image://%s/'%imgCache1).read())

             except:
                print "fail"
                pass
         if showDialog==1:       
            imgDialog.close()
         myMusicVideos.sync()
         myMusicVideosCheck.sync()
         xbmcplugin.endOfDirectory(addon_handle)
         print "end cav image resize"
      print "clean to use again"   
      xbmcgui.Window( 10000 ).clearProperty('CAVPLUS_RESIZE')
   else:
      icon = __icon__
      li = xbmcgui.ListItem("IMGERROR", iconImage=__icon__,thumbnailImage=__icon__)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=icon,listitem=li, isFolder=True)
      xbmcplugin.endOfDirectory(addon_handle)        

addon_handle = 5 
def get_params():
    print "services called"
        
if (__name__ == "__main__"):
   runOnStartup = __settings__.getSetting("runOnStartup")
   print "****************+***********", runOnStartup
   if runOnStartup=="true":
      _resizeImg()
      _resizeImgBanners()
      _resizeImgPosters()
   Main()
   del Widgets_Monitor
   del Main

