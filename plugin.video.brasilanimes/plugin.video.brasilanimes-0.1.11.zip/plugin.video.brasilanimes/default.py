import urllib,re,string,sys,os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import time,threading
from xbmcswift2 import Plugin 
myPlugin2 = Plugin()
from resources.lib import anitube,mvonline,mgserieson, myResolver,favorites 
__addon__        = xbmcaddon.Addon()
__cwd__        = __addon__.getAddonInfo('path')
__addonid__      = __addon__.getAddonInfo('id')
__icon__          = __addon__.getAddonInfo("icon")
profile = xbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='plugin.video.brasilanimes')
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )

mySearch = myPlugin2.get_storage('search.json', file_format='json')
myFavorites = myPlugin2.get_storage('favorites.json', file_format='json')

baseUrl = "http://anitube.xpg.uol.com.br/"
categoryUrl = "http://anitube.xpg.uol.com.br/categories"

def MAIN():
    icon = __icon__
    
    xbmcplugin.setContent(addon_handle, 'files')
    li = xbmcgui.ListItem("ANITUBE", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=50&url=%s")%(myPlugin,baseUrl)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem("MEGA SERIES ONLINE", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=100")%myPlugin
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)  
    
    
    xbmcplugin.endOfDirectory(addon_handle)  


def chooseLink(url):
    if re.search("dropvideo",url):
       url = myResolver.resolve_dropvideo(url)
       if url: playLink(url)
    elif re.search("vidto",url):
       url = myResolver.refererResolver(url)
       if url: playLink(url)


def playLink(url):
    listitem = xbmcgui.ListItem(path=url)
    xbmc.Player( xbmc.PLAYER_CORE_MPLAYER ).play(url, listitem)



def get_params():
    print "***************************************************************************************************************************"
    print sys.argv
    param=[]
    paramstring=sys.argv[2]
    
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

        
params=get_params()
myPlugin = sys.argv[0]
addon_handle = int(sys.argv[1])
mode= None
url =None



try: url=urllib.unquote_plus(params["url"])
except: pass
try: mode=int(params["mode"])
except: pass


if mode == None and url==None:
   print "MAIN WINDOW"
   #source = "https://r1---sn-bg07dne6.c.docs.google.com/videoplayback?requiressl=yes&shardbypass=yes&cmbypass=yes&id=8793eaa5eb35ae32&itag=22&source=webdrive&app=docs&ip=179.108.133.152&ipbits=0&expire=1398696076&sparams=requiressl,shardbypass,cmbypass,id,itag,source,ip,ipbits,expire&signature=7AA8CFD51A3598EDCAAFB8AC5EB446DF419099D8.3E41889F224657571E4048EB6421E131589FD39D&key=ck2&ir=1&ms=nxu&mt=1398692431&mv=m&mws=yes\u0026type\u003dvideo/mp4"
   
   MAIN()

elif mode==50 and url:
   anitube.MAIN()
elif mode==1 and url:
   print url,"i am here"
   anitube.getHome(url)
elif mode==2 and url:
   print url,"i am here"
   anitube.getLinkHome(url)
elif mode==3 and url:
   print url,"i am here 3"
   anitube.playLink(url)
elif mode==4 and url:
   print url,"i am here 3"
   anitube.getCategory(url)
elif mode==5 and url:
   print url,"i am here 3"
   anitube.getCategoryItems(url)

elif mode==6:
   cat = params["cat"]
   favorites.menuSearch(cat)
elif mode==7 and url:
   #http://anitube.xpg.uol.com.br/search/2/?sort=&search_type=videos&search_id=naruto&search_key=
   #url http://anitube.xpg.uol.com.br/search/2/?sort=
   print sys.argv[2]
   print "search xxxxxxxxxxxxxxxxxxxx",url
   print params["search_id"]
   fullUrl = url+"&search_type=videos&search_id="+params["search_id"]+"&search_key="
   anitube.searchAnimeItems(fullUrl)   

elif mode==8:
   cat = params["cat"]
   favorites.reqSearch(cat)  
elif mode==9:
   cat = params['cat']
   favorites.sarchClean(cat)

elif mode==10:
   cat = params["cat"]
   name = params["name"]
   thumbnail = params["thumbnail"]
   favorites.addFavorites(url,name,thumbnail,cat)
elif mode==11:
   cat = params['cat']
   favorites.getFavorites(cat)
elif mode==12:
   cat = params['cat']
   name = params["name"]
   favorites.delFavorites(name,cat)
elif mode==13:
   cat = params["cat"]
   favorites.favoriteClean(cat)     

elif mode==14:
   anitube.getPage()
elif mode==15:
   cod = params['cod']
   name = params['name']
   anitube.getPageItem(cod,name)   

#multi_videos _online   
elif mode==100:
   mgserieson.MAIN()
elif mode==101:
   print "call home"
   type1 = ""
   if params["type"]: type1 = params["type"]
   mgserieson.getHome(url,type1)
elif mode==102:
   mgserieson.getSeasons(url)
elif mode==103:
   print "will get links"
   d= ""
   try:
      d= params["d"]
   except:
      pass   
   mgserieson.getLinks(url,d)
elif mode==104:
   chooseLink(url)
elif mode==105:
   name = params["name"]
   thumbnail = params["thumbnail"]
   mgserieson.addFavorites(url,name,thumbnail)
elif mode==106:
   mgserieson.getHome(url,"RESULTADODABUSCA")
                             