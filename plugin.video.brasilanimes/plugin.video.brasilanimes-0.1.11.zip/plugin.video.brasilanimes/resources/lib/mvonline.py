import urllib,re,string,sys,os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import time,threading
from xbmcswift2 import Plugin 
import urllib
from urllib import quote
import myResolver
import urllib2
from BeautifulSoup import BeautifulSoup, NavigableString, Tag



myPlugin2 = Plugin() 
__addon__        = xbmcaddon.Addon()
__cwd__        = __addon__.getAddonInfo('path')
__addonid__      = __addon__.getAddonInfo('id')
__icon__          = __addon__.getAddonInfo("icon")
profile = xbmc.translatePath(__addon__.getAddonInfo('profile').decode('utf-8'))
__addonversion__ = __addon__.getAddonInfo('version')
__settings__   = xbmcaddon.Addon(id='plugin.video.brasilanimes')
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )


mySearch = myPlugin2.get_storage('search.json', file_format='json')
myFavorites = myPlugin2.get_storage('favorites.json', file_format='json')

baseUrl = "https://multi-videos-online.blogspot.com.br/"
categoryUrl = "http://anitube.xpg.uol.com.br/categories"

animeD = "https://multi-videos-online.blogspot.com.br/search/label/z-baixar%20animes%20dublados"
animeL = "https://multi-videos-online.blogspot.com.br/search/label/z-baixar%20animes%20legendados"
desenhoD = "https://multi-videos-online.blogspot.com.br/search/label/z-baixar%20desenhos%20dublados"
desenhoL = "https://multi-videos-online.blogspot.com.br/search/label/z-baixar%20desenhos%20legendados"
serieD = "https://multi-videos-online.blogspot.com.br/search/label/z-baixar%20series%20dubladas"
serieL = "https://multi-videos-online.blogspot.com.br/search/label/z-baixar%20series%20legendadas"

def MAIN():
    icon = __icon__
    print  "anitube ----------------------------------------------------"
    xbmcplugin.setContent(addon_handle, 'files')
    url = animeD
    li = xbmcgui.ListItem("Anime Dublado", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=101&url=%s")%(myPlugin,url)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    url = animeL
    li = xbmcgui.ListItem("Anime Legendado", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=101&url=%s")%(myPlugin,url)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    url = desenhoD
    li = xbmcgui.ListItem("Desenho Dublado", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=101&url=%s")%(myPlugin,url)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    url = desenhoL
    li = xbmcgui.ListItem("Desenho Legendado", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=101&url=%s")%(myPlugin,url)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    url = serieD
    li = xbmcgui.ListItem("Serie Dublada", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=101&url=%s")%(myPlugin,url)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    url = serieL
    li = xbmcgui.ListItem("Serie Legendada", iconImage=icon,thumbnailImage=icon)
    url  = ("%s?mode=101&url=%s")%(myPlugin,url)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)  





def getHome(url):
    url = url.replace(" ","%20")
    url = url.replace("http:","https:")
    xbmcplugin.setContent(addon_handle, 'files')
    link = OPENURL(url)
    
    
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    
    pgPrevious = re.findall('<a class=\'blog-pager-newer-link\' href=\'(.+?)\' id=\'Blog1_blog-pager-newer-link\' title=(.+?)</a>',link)
    pgNext = re.findall('<a class=\'blog-pager-older-link\' href=\'(.+?)\' id=\'Blog1_blog-pager-older-link\' title=(.+?)</a>',link)
    if pgPrevious and pgPrevious[0]:
       url  = ("%s?mode=101&url=%s")%(myPlugin,pgPrevious[0][0])
       li = xbmcgui.ListItem("Anterior")
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)  
    if pgNext and pgNext[0]:
       url  = ("%s?mode=101&url=%s")%(myPlugin,pgNext[0][0])
       li = xbmcgui.ListItem("Proxima")
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)    
    
    match = re.findall('<h2 class=\'post-title entry-title\'><a href=\'(.+?)\'>(.+?)</a></h2><div class=\'postmeta\'><span class=(.+?)src="(.+?)" (.+?) /><br />',link)
    #url,title,author,clock,url2,comment,summary,img1,img2,img3
    for url,title,value,img,img2 in match:
       li = xbmcgui.ListItem(title, thumbnailImage=img)
       url  = ("%s?mode=102&url=%s")%(myPlugin,url)
       print url
       li.setInfo(type="Video", infoLabels={"title": title})   
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)  
    xbmcplugin.endOfDirectory(addon_handle) 

def getItems(url2):
    url = "http://fs003.dropvideo.com/v/0c53426db9f63d99819cabe6353464cd.mp4?st=mp3YcFD5P19UAfmV14b37Q"
    listitem = xbmcgui.ListItem(path=url)
    xbmc.Player( xbmc.PLAYER_CORE_MPLAYER ).play(url, listitem)

def getItems1(url):
    url = url.replace(" ","%20")
    url = url.replace("http:","https:")
    link = OPENURL(url)
    #link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    link = link.replace('<div>\n<div','<div') 
    #link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    print repr(link)
    soup = BeautifulSoup(link)
    
    getClass  = soup.find(attrs={'class' :"post-body entry-content"})
    for tag in getClass.findAll(['span','a','div','b']):
       #tag.replaceWith('')
       del(tag['style'])

    print "getclasss", getClass.prettify
    
    testSpan = getClass.findAll('span')
    for line in testSpan:
       print "line", repr(line)
       
    soup = BeautifulSoup(link)
    #getClass = soup.findAll('class'="post-body entry-content")
    #works getClass  = soup.findAll(attrs={'class' : re.compile("post-body entry-content$")})
    getClass  = soup.find(attrs={'class' :"post-body entry-content"})

    print "getclasss",getClass.prettify
    if getClass:
       img = getClass.find('img')["src"]
       print "next div",getClass.findAll('div')
       allDiv = getClass.findAll('div')
       allBr = getClass.findAll('br')
       print "br 0",allDiv[0]
       print "image",img
       for br in getClass.findAll('br'):
           next = br.nextSibling
           if not (next and isinstance(next,NavigableString)):
               continue
           next2 = next.nextSibling
           if next2 and isinstance(next2,Tag) and next2.name == 'br':
               text = str(next).strip()
               if text:
                   print "Found:", repr(text)       
       
    #soup.find("b", { "class" : "lime" })
    
    #print soup.prettify()   



def getItems2(url):
    #myFile = myResolver.resolve_firedrive("http://www.firedrive.com/file/9A315BA33D231D09")
    #myFile = myResolver.resolveMBLink("http://vk.com/video_ext.php?oid=244817355&id=167974021&hash=3c5e06b957231aa2&hd=1")
    #playLink(myFile)
    url = url.replace(" ","%20")
    url = url.replace("http:","https:")
    link = OPENURL(url)

    
    
    
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    link  = link.replace('class="video cboxElement" ',"").replace('style="color: black; font-weight: bold; text-decoration: none;"',"").replace('</strong> &- ',"").replace('&- </strong>',"").replace('</strong>&- ',"")
    link = link.replace('style="color: #666666; font-family: Roboto, sans-serif; font-size: 17px; line-height: 23.100000381469727px; text-align: center; text-decoration: none;"',"")
    link = link.replace('</span><br /><b style="background-color: white; color: #333333; font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 19.600000381469727px; text-align:',"")
    link = link.replace('style="-webkit-transition: color 0.3s; color: #009eb8; display: inline; font-family: \'Helvetica Neue Light\', HelveticaNeue-Light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; outline: none; text-decoration: none; transition: color 0.3s;">MEGA</a></span><span style="background-color: white; color: #333333; font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 19.600000381469727px; text-align:',"")
    link = link.replace('i+FHD</b>(1080p) -',"").replace('i+SD</b>(480p) -',"")
    #reCompile = re.compile('<br />(.+?):<br />idioma :(.+?)<br />(.+?)<br />(.+?)<br />',re.IGNORECASE)
    #link   = reCompile.sub('<br />%s:<br />idioma :%s<br />%s<br />%s<br />'%("","","",""),link)
    #link = re.sub('<br />(.+?):<br />IDIOMA:(.+?)<br />(.+?):(.+?)<br />',"",link,re.IGNORECASE)
    #link = re.sub('<br />(.+?):<br />idioma(.+?):(.+?)<br />(.+?)<br />(.+?)<br />',"",link,re.IGNORECASE)
    
    
    print link
    files = re.findall('<div class=\'post-body entry-content\'>(.+?)<div style',link)
    if files:
       print "files ++++++++++++ ",len(files)
       print "files ++++++++++++ ",files[0]
       print "has files"
       img = re.findall('<img(.+?)src="(.+?)"(.+?)/>',files[0])
       print img[0][1]
       filesB = []
       filesLinksStrong = re.findall('<strong>(.+?)</div>',files[0])
       
       
       if not filesLinksStrong:
          filesLinksStrong  = re.findall('baseline;">(.+?)</a></span></div>',files[0])
          for links in filesLinksStrong:
             print "baseline"
             print links
       
       if not filesLinksStrong:
          filesLinksStrong  = re.findall('<b>(.+?)center;">',files[0])
          for links in filesLinksStrong:
             print "BBBBBB"
             print links
             
       if not filesLinksStrong:
          filesLinksStrong  = re.findall('<br />(.+?)</a><br />',files[0])
          for links in filesLinksStrong:
             print "br barra"
             print links
             
       
       for links in filesLinksStrong:
          links  = parseLink(links)
          print links

def parseLink(link):
    link = re.sub('(.+?):<br />idioma(.+?):(.+?)<br />(.+?)<br />(.+?)<br />',"",link,re.IGNORECASE)
    link = re.sub('(.+?):<br />IDIOMA(.+?):(.+?)<br />(.+?)<br />(.+?)<br />',"",link,re.IGNORECASE)
    link = re.sub('(.+?):<br />IDIOMA(.+?):(.+?)<br />(.+?)<br />',"",link,re.IGNORECASE)
    link = re.sub('(.+?):<br />(.+?)<br />IDIOMA(.+?):(.+?)<br />',"",link,re.IGNORECASE)
    link = link.replace('-</strong>',"")
    return link
       
def getLinkHome(url):
    link = OPENURL(url)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')

    match = re.findall('src="http://anitube.xpg.uol.com.br/embed/(.+?)" frameborder="0"></iframe>',link)
    idFile =  match[0]
    linkFile  = "http://anitube.xpg.uol.com.br/nuevo/econfig.php?key=%s"%idFile
    link = OPENURL(linkFile)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    #http://anitube.xpg.uol.com.br/nuevo/econfig.php?key=7e4ed8971cb4ec0c8c4b
    #<file>http://chi08.vid.anitu.be/26_QRqAY6qr2CaXpbUEQmA/1398632509/69936.mp4</file><filehd>http://chi08.vid.anitu.be/avJaRTsOqFrMdS_ozD9znw/1398632509/69936_hd.mp4</filehd>
    file = re.findall('<file>(.+?)</file>',link)
    fileHd = re.findall('<filehd>(.+?)</filehd>',link)
    fileHtml = re.findall('<html5>(.+?)</html5>',link)
    img = re.findall('<image>(.+?)</image>',link)
    img = img[0]
    print img
    if file:
       url  = file[0]
       li = xbmcgui.ListItem("Normal", thumbnailImage=img)
       url  = ("%s?mode=3&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    if fileHd:
       url  = fileHd[0]
       li = xbmcgui.ListItem("HD", thumbnailImage=img)
       url  = ("%s?mode=3&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    if fileHtml:
       url  = fileHtml[0]
       li = xbmcgui.ListItem("Html", thumbnailImage=img)
       url  = ("%s?mode=3&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)       
    xbmcplugin.endOfDirectory(addon_handle) 


def getCategory(url):
    contextMenuItems = []
    xbmcplugin.setContent(addon_handle, 'episodes')
    link = OPENURL(url)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    pagination  = re.findall('<ul id="pagination-flickr">(.+?)</ul>',link)
    next = re.findall('<li><a href="(.+?)">(.+?)</a></li>',pagination[0])     
    for url,page in next:
       print url,page
       li = xbmcgui.ListItem(page)
       url  = ("%s?mode=4&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
       
    
    match = re.findall('<li class="mainList"> <div class="videoThumb"> <a href="(.+?)" title="(.+?)"><img src="(.+?)" alt="(.+?)" /></a> </div> <div class="catTitle">',link)
    for url,view,img,title in match:
       contextMenuItems = []
       li = xbmcgui.ListItem(title, thumbnailImage=img)
       contextMenuItems.append(("Adicionar aos Favoritos",'XBMC.RunScript(%s,%s,?mode=%s&url=%s&name=%s&thumbnail=%s)'% ("plugin.video.brasilanimes",1,"10",url,title,img)))
       url  = ("%s?mode=5&url=%s")%(myPlugin,url)
       print url
       li.setInfo(type="Video", infoLabels={"title": title, "plot": view})   
       li.addContextMenuItems(contextMenuItems, replaceItems=True)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)    
    
    xbmcplugin.endOfDirectory(addon_handle)     

def getCategoryItems(url):
    xbmcplugin.setContent(addon_handle, 'episodes')
    link = OPENURL(url)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    #print link
    pagination  = re.findall('<ul id="pagination-flickr">(.+?)</ul>',link)
    next = re.findall('<li><a href="(.+?)">(.+?)</a></li>',pagination[0])     
    for url,page in next:
       print url,page
       li = xbmcgui.ListItem(page)
       url  = ("%s?mode=5&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)  
    
     
    match = re.findall('li class="mainList"> <div class="videoThumb"> <a href="(.+?)" title="(.+?)"><img src="(.+?)" alt="(.+?)" id="(.+?)" /></a> </div> <div class="videoTitle">',link)
    totalLinks = len(match)
    for url,title,img,alt,id in match:
       li = xbmcgui.ListItem(alt, thumbnailImage=img)
       url  = ("%s?mode=2&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    xbmcplugin.endOfDirectory(addon_handle)

def searchAnimeClean():                                         
   file  = os.path.join(myPlugin2.storage_path,'search.json')
   if os.path.exists(file):
        os.remove(file)
   

def searchAnime():
    li = xbmcgui.ListItem("Search")
    url  = ("%s?mode=8")%myPlugin
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    li = xbmcgui.ListItem("Apagar Todos")
    url  = ("%s?mode=9")%myPlugin
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    for i, search in enumerate(mySearch):
      keySearch = search
      url  = mySearch[search]
      icon = __icon__
      li = xbmcgui.ListItem(search)
      url  = ("%s?mode=7&url=%s")%(myPlugin,url)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    xbmcplugin.endOfDirectory(addon_handle)
def searchAnime2():
    keyboard = xbmc.Keyboard("", 'Search', False)
    keyboard.doModal()
    
    if keyboard.isConfirmed():
         query = keyboard.getText()
         url = "http://anitube.xpg.uol.com.br/search/basic/1/?sort=title&search_type=videos&search_id="+query
         if not query in mySearch :
            mySearch[query] = url
            mySearch.sync()
         searchAnimeItems(url)

def searchAnimeItems(url):
    xbmcplugin.setContent(addon_handle, 'episodes')
    link = OPENURL(url)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    print link
    pagination  = re.findall('<ul id="pagination-flickr">(.+?)</ul>',link)
    next = re.findall('<li><a href="(.+?)">(.+?)</a></li>',pagination[0])     
    for url,page in next:
       print url,page
       li = xbmcgui.ListItem(page)
       url  = ("%s?mode=7&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    
    
    match = re.findall('<li class="mainList"> <div class="videoThumb"> <a href="(.+?)" title="(.+?)"><img src="(.+?)" id="(.+?)" alt="(.+?)" /></a> </div> <div class="videoTitle">',link) 
    totalLinks = len(match)
    for url,title,img,id,alt in match:
       li = xbmcgui.ListItem(alt, thumbnailImage=img)
       url  = ("%s?mode=2&url=%s")%(myPlugin,url)
       xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    xbmcplugin.endOfDirectory(addon_handle)

def addFavorites(url,name,thumbnail):
    myFavorites[name] = {}
    myFavorites[name]["url"] = url
    myFavorites[name]["thumbnail"] = thumbnail
    myFavorites.sync() 

def getFavorites():

    for i, favorite in enumerate(myFavorites):
      url  = myFavorites[favorite]["url"]
      thumbnail  = myFavorites[favorite]["thumbnail"]
      icon = __icon__
      li = xbmcgui.ListItem(favorite,thumbnailImage=thumbnail)
      url  = ("%s?mode=5&url=%s")%(myPlugin,url)
      xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True) 
    xbmcplugin.endOfDirectory(addon_handle)


def playLink(url):
    listitem = xbmcgui.ListItem(path=url)
    xbmc.Player( xbmc.PLAYER_CORE_MPLAYER ).play(url, listitem)

def getUrl(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link


def OPENURL(url, mobile = False, q = False, verbose = True, timeout = 10, cookie = None, data = None, cookiejar = False, log = True, headers = [], type = '',ua = False):
    import urllib2 
    UserAgent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
    if ua: UserAgent = ua
    try:
        if log:
            print "MU-Openurl = " + url
        if cookie and not cookiejar:
            import cookielib
            cookie_file = os.path.join(os.path.join(datapath,'Cookies'), cookie+'.cookies')
            cj = cookielib.LWPCookieJar()
            if os.path.exists(cookie_file):
                try: cj.load(cookie_file,True)
                except: cj.save(cookie_file,True)
            else: cj.save(cookie_file,True)
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        elif cookiejar:
            import cookielib
            cj = cookielib.LWPCookieJar()
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        else:
            opener = urllib2.build_opener()
        if mobile:
            opener.addheaders = [('User-Agent', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7')]
        else:
            opener.addheaders = [('User-Agent', UserAgent)]
        for header in headers:
            opener.addheaders.append(header)
        if data:
            if type == 'json': 
                import json
                data = json.dumps(data)
                opener.addheaders.append(('Content-Type', 'application/json'))
            else: data = urllib.urlencode(data)
            response = opener.open(url, data, timeout)
        else:
            response = opener.open(url, timeout=timeout)
        if cookie and not cookiejar:
            cj.save(cookie_file,True)
        link=response.read()
        response.close()
        opener.close()
        #link = net(UserAgent).http_GET(url).content
        link=link.replace('&#39;',"'").replace('&quot;','"').replace('&amp;',"&").replace("&#39;","'").replace('&lt;i&gt;','').replace("#8211;","-").replace('&lt;/i&gt;','').replace("&#8217;","'").replace('&amp;quot;','"').replace('&#215;','x').replace('&#038;','&').replace('&#8216;','').replace('&#8211;','').replace('&#8220;','').replace('&#8221;','').replace('&#8212;','')
        link=link.replace('%3A',':').replace('%2F','/')
        if q: q.put(link)
        return link
    except Exception as e:
        if verbose:
            xbmc.executebuiltin("XBMC.Notification(Sorry!,Source Website is Down,3000,"+elogo+")")
        xbmc.log('***********Website Error: '+str(e)+'**************', xbmc.LOGERROR)
        import traceback
        traceback.print_exc()
        link ='website down'
        if q: q.put(link)
        return link

    
def get_params():
    print sys.argv
    param=[]
    paramstring=sys.argv[2]
    
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

        
params=get_params()
myPlugin = sys.argv[0]
addon_handle = int(sys.argv[1])
mode= None
url =None

print sys.argv
           